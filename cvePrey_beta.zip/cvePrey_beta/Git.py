import cveprey, json, sys

adv = 'https://gitlab.com/gitlab-org/cves/-/raw/master/%s/%s.json'
data = set()
pat = [
    '^\\s*gitlab-[ce]e\\s+(\\d{1,2}\\.[\\.\\d]+).?\\w?\\w?\\d?\\d?$',
    '^\\s*gitlab-ce\\s+(\\d{1,2}\\.[\\.\\d]+).?\\w?\\w?\\d?\\d?$',
    '^\\s*gitlab-ee\\s+(\\d{1,2}\\.[\\.\\d]+).?\\w?\\w?\\d?\\d?$'
]

def eval_g(cve, data, json, n) -> None:
    '''
    loads the def templates of gitlab family and process the variable's
    params:
        cve: str
        data: dict
        json: str
        md: str
        n: int
        rtype: None
    '''
    temp = open(f'gitlab{n}.xml', 'r')
    tmp = temp.read()
    temp.close()

    print('Generating Template ...')
    temp = open(cve+'-lin-gitlab'+'.xml', 'w')
    tmp = tmp.format(data=data)
    temp.write(tmp)
    temp.close()
    temp = open(cve+'.json', 'w')
    temp.write(json)
    temp.close()
    print("Done ... !")

class _Git():
    def __init__(self, cve:str, mode) -> None:
        self.cve = cve
        self.cve_raw = "".join(cve.split('-')[1::])
        self.mode = mode
        self.year = cve.split('-')[1]
        self.prc(self.cve, self.mode, self.year)

    def prc(self, cve:str, mode:str, year:str):
        responseJson = cveprey.gitLabAdvisories(cve)
        desc = responseJson.description
        title = responseJson.title
        versions_list = responseJson.affected_versions

        print(versions_list)
                
        data = {'year': year, 'cve': cve, 'cve_raw': self.cve_raw, 'title': title, 'desc': desc, 
                'mb1': versions_list[0][0], 'v1': versions_list[0][1], 
                'omb1': "".join([f'{ver:0>2}' for ver in versions_list[0][0].split('.')]), 
                'ov1': "".join([f'{ver:0>2}' for ver in versions_list[0][1].split('.')]),
                'pat': pat[0], 'patn': '2'}
        if len(versions_list) == 2:
            num = 2
            data.update({'mb2': versions_list[1][0], 'v2': versions_list[1][1],
                        'omb2': "".join([f'{ver:0>2}' for ver in versions_list[1][0].split('.')]), 
                        'ov2': "".join([f'{ver:0>2}' for ver in versions_list[1][1].split('.')])})
            if mode == 'ee':
                data.update({'pat': pat[2]})
                data.update({'patn': '3'})
            elif mode == 'ce':
                data.update({'pat': pat[1]})
                data.update({'patn': '4'})
            else:
                data.update({'pat': pat[0]})
                data.update({'patn': '2'})
        elif len(versions_list) == 1:
            num = 1
            if mode == 'ee':
                data.update({'pat': pat[2]})
                data.update({'patn': '3'})
            if mode == 'ce':
                data.update({'pat': pat[1]})
                data.update({'patn': '4'})
        elif len(versions_list) == 4:
            num = 4
            data.update({'mb2': versions_list[1][0], 'v2': versions_list[1][1], 
                         'mb3': versions_list[2][0], 'v3': versions_list[2][1], 
                         'mb4': versions_list[3][0], 'v4': versions_list[3][1],
                        'omb2': "".join([f'{ver:0>2}' for ver in versions_list[1][0].split('.')]), 
                        'ov2': "".join([f'{ver:0>2}' for ver in versions_list[1][1].split('.')]),
                        'omb3': "".join([f'{ver:0>2}' for ver in versions_list[2][0].split('.')]), 
                        'ov3': "".join([f'{ver:0>2}' for ver in versions_list[2][1].split('.')]),
                        'omb4': "".join([f'{ver:0>2}' for ver in versions_list[3][0].split('.')]), 
                        'ov4': "".join([f'{ver:0>2}' for ver in versions_list[3][1].split('.')])})
            if mode == 'ee':
                data.update({'pat': pat[2]})
                data.update({'patn': '3'})
            elif mode == 'ce':
                data.update({'pat': pat[1]})
                data.update({'patn': '4'})
            else:
                data.update({'pat': pat[0]})
                data.update({'patn': '2'})
        else:
            num = 3
            data.update({'mb2': versions_list[1][0], 'v2': versions_list[1][1],
                          'mb3': versions_list[2][0], 'v3': versions_list[2][1],
                        'omb2': "".join([f'{ver:0>2}' for ver in versions_list[1][0].split('.')]), 
                        'ov2': "".join([f'{ver:0>2}' for ver in versions_list[1][1].split('.')]),
                        'omb3': "".join([f'{ver:0>2}' for ver in versions_list[2][0].split('.')]), 
                        'ov3': "".join([f'{ver:0>2}' for ver in versions_list[2][1].split('.')])})
            if mode == 'ee':
                data.update({'pat': pat[2]})
                data.update({'patn': '3'})
            elif mode == 'ce':
                data.update({'pat': pat[1]})
                data.update({'patn': '4'})
            else:
                data.update({'pat': pat[0]})
                data.update({'patn': '2'})
        
        print(num)
        data.update({'product': 'Tanium Comply', 'company': 'tanium'})
        data.update({'date': '2023-07-07T12:05:49.144+05:30'})
        eval_g(cve, data, str(responseJson), num)

_Git(sys.argv[1], mode="ee")