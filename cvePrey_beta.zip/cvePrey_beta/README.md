# CVE Prey
_A CVE Automation Framework_

### Installation
```bash
$ git clone https://github.com/iam048/cvePrey.git
$ cd cvePrey/
$ python3 setup.py install --user
```

### Working with Package
```python3
>>> import cveprey
>>> cve_info = cveprey.CVE("CVE-2021-1337")
>>> cve_info.get_nvd_data()
>>> cve_info.nvd_data.description
'Multiple vulnerabilities in the web-based management interface of Cisco Small Business RV016, RV042, RV042G, RV082, RV320, and RV325 Routers could allow an authenticated, ..[SNIP].. affected device.'
```

### Note:
```text
Copy geckodriver Binary to $HOME/.local/bin/geckodriver to work with synchronous browsers
```