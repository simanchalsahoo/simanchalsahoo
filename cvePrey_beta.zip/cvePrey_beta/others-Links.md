https://geolocation.onetrust.com/cookieconsentpub/v1/geo/location

https://api.company-target.com/api/v2/ip.json?referrer=https%3A%2F%2Fwww.google.com%2F&page=https%3A%2F%2Fwww.vmware.com%2Fsecurity%2Fadvisories.html&page_title=Advisories

https://api.company-target.com/api/v2/ip.js?key=yhM3aXuMmXqyt2Dy5b4prrxMmug10POPRguNDfMk&var=db