import cveprey, sys

criteria_windows = ''
criteria_linux = ''
criteria_macos = ''

tests_windows = ''
states_windows = ''

tests_linux = ''
states_linux = ''

tests_macos = ''
states_macos = ''

criteria_AND = '''
<criteria operator="AND" comment="check for affected version {data[pat]}">
{data[criterions]}
</criteria>
'''

criteria_OR = '''
<criteria operator="OR" comment="check for affected version {data[pat]}">
{data[criterions]}
</criteria>
'''

# Windows
criterion_windows_l='''
<criterion test_ref="oval:org.tanium.windows.splunk.cve:tst:12{data[ver_id]}02" negate="false" comment="Check for Splunk Enterprise affected version is less than or equal to {data[ver]}"/>
'''
criterion_windows_e='''
<criterion test_ref="oval:org.tanium.windows.splunk.cve:tst:12{data[ver_id]}00" negate="false" comment="Check for Splunk Enterprise affected version is equals to {data[ver]}"/>
'''
criterion_windows_g='''
<criterion test_ref="oval:org.tanium.windows.splunk.cve:tst:12{data[ver_id]}04" negate="false" comment="Check for Splunk Enterprise affected version is greater than or equal to {data[ver]}"/>
'''

ver_test_windows_l = '''
<registry_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#windows" id="oval:org.tanium.windows.splunk.cve:tst:12{data[ver_id]}02" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Splunk Enterprise affected version is less than or equal to {data[ver]}" deprecated="false">
      <object object_ref="oval:org.tanium.windows.splunk.cve:obj:1002"/>
      <state state_ref="oval:org.tanium.windows.splunk.cve:ste:12{data[ver_id]}02"/>
    </registry_test>
'''
ver_test_windows_e = '''
<registry_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#windows" id="oval:org.tanium.windows.splunk.cve:tst:12{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Splunk Enterprise affected version is equals to {data[ver]}" deprecated="false">
      <object object_ref="oval:org.tanium.windows.splunk.cve:obj:1002"/>
      <state state_ref="oval:org.tanium.windows.splunk.cve:ste:12{data[ver_id]}00"/>
    </registry_test>
'''
ver_test_windows_g = '''
<registry_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#windows" id="oval:org.tanium.windows.splunk.cve:tst:12{data[ver_id]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Splunk Enterprise affected version is greater than or equal to {data[ver]}" deprecated="false">
      <object object_ref="oval:org.tanium.windows.splunk.cve:obj:1002"/>
      <state state_ref="oval:org.tanium.windows.splunk.cve:ste:12{data[ver_id]}04"/>
    </registry_test>
'''

ver_state_windows_l='''
<registry_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#windows" id="oval:org.tanium.windows.splunk.cve:ste:12{data[ver_id]}02" version="1" operator="AND" comment="State for Splunk Enterprise version is less than or equal to {data[ver]}" deprecated="false">
      <value entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="less than or equal" mask="false">{data[ver]}</value>
    </registry_state>
'''
ver_state_windows_e='''
<registry_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#windows" id="oval:org.tanium.windows.splunk.cve:ste:12{data[ver_id]}00" version="1" operator="AND" comment="State for Splunk Enterprise version is equals to {data[ver]}" deprecated="false">
      <value entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="equals" mask="false">{data[ver]}</value>
    </registry_state>
'''
ver_state_windows_g='''
<registry_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#windows" id="oval:org.tanium.windows.splunk.cve:ste:12{data[ver_id]}04" version="1" operator="AND" comment="State for Splunk Enterprise version is greater than or equal to {data[ver]}" deprecated="false">
      <value entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[ver]}</value>
    </registry_state>
'''

# Linux
criteria_full_linux_g_l = '''
<criteria operator="AND" comment="check for {data[pat]} DPKG">
    <criterion test_ref="oval:org.tanium.unix.splunk.cve:tst:15{data[ver_id_1]}04" negate="false" comment="Check for Splunk Enterprise affected version is greater than or equal to {data[ver_1]} (DPKG)"/>
    <criterion test_ref="oval:org.tanium.unix.splunk.cve:tst:15{data[ver_id_2]}02" negate="false" comment="Check for Splunk Enterprise affected version is less than or equal to {data[ver_2]} (DPKG)"/>
</criteria>
<criteria operator="AND" comment="check for {data[pat]} RPM">
    <criterion test_ref="oval:org.tanium.unix.splunk.cve:tst:16{data[ver_id_1]}04" negate="false" comment="Check for Splunk Enterprise affected version is greater than or equal to {data[ver_1]} (RPM)"/>
    <criterion test_ref="oval:org.tanium.unix.splunk.cve:tst:16{data[ver_id_2]}02" negate="false" comment="Check for Splunk Enterprise affected version is less than or equal to {data[ver_2]} (RPM)"/>
</criteria>
'''

criterion_linux_l='''
<criterion test_ref="oval:org.tanium.unix.splunk.cve:tst:15{data[ver_id]}02" negate="false" comment="Check for Splunk Enterprise affected version is less than or equal to {data[ver]} (DPKG)"/>
<criterion test_ref="oval:org.tanium.unix.splunk.cve:tst:16{data[ver_id]}02" negate="false" comment="Check for Splunk Enterprise affected version is less than or equal to {data[ver]} (RPM)"/>
'''

criterion_linux_e='''
<criterion test_ref="oval:org.tanium.unix.splunk.cve:tst:15{data[ver_id]}00" negate="false" comment="Check for Splunk Enterprise affected version is equals to {data[ver]} (DPKG)"/>
<criterion test_ref="oval:org.tanium.unix.splunk.cve:tst:16{data[ver_id]}00" negate="false" comment="Check for Splunk Enterprise affected version is equals to {data[ver]} (RPM)"/>
'''

ver_test_linux_l = '''
<dpkginfo_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:tst:15{data[ver_id]}02" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Splunk Enterprise affected version is less than or equal to {data[ver]} (DPKG)" deprecated="false">
      <object object_ref="oval:org.tanium.unix.splunk.cve:obj:1000"/>
      <state state_ref="oval:org.tanium.unix.splunk.cve:ste:15{data[ver_id]}02"/>
    </dpkginfo_test>
    <rpminfo_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:tst:16{data[ver_id]}02" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Splunk Enterprise affected version is less than or equal to {data[ver]} (RPM)" deprecated="false">
      <object object_ref="oval:org.tanium.unix.splunk.cve:obj:2000"/>
      <state state_ref="oval:org.tanium.unix.splunk.cve:ste:16{data[ver_id]}02"/>
    </rpminfo_test>
'''
ver_test_linux_e = '''
<dpkginfo_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:tst:15{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Splunk Enterprise affected version is equals to {data[ver]} (DPKG)" deprecated="false">
      <object object_ref="oval:org.tanium.unix.splunk.cve:obj:1000"/>
      <state state_ref="oval:org.tanium.unix.splunk.cve:ste:15{data[ver_id]}00"/>
    </dpkginfo_test>
    <rpminfo_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:tst:16{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Splunk Enterprise affected version is equals to {data[ver]} (RPM)" deprecated="false">
      <object object_ref="oval:org.tanium.unix.splunk.cve:obj:2000"/>
      <state state_ref="oval:org.tanium.unix.splunk.cve:ste:16{data[ver_id]}00"/>
    </rpminfo_test>
'''
ver_test_linux_g = '''
<dpkginfo_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:tst:15{data[ver_id]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Splunk Enterprise affected version is greater than or equal to {data[ver]} (DPKG)" deprecated="false">
      <object object_ref="oval:org.tanium.unix.splunk.cve:obj:1000"/>
      <state state_ref="oval:org.tanium.unix.splunk.cve:ste:15{data[ver_id]}04"/>
    </dpkginfo_test>
    <rpminfo_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:tst:16{data[ver_id]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Splunk Enterprise affected version is greater than or equal to {data[ver]} (RPM)" deprecated="false">
      <object object_ref="oval:org.tanium.unix.splunk.cve:obj:2000"/>
      <state state_ref="oval:org.tanium.unix.splunk.cve:ste:16{data[ver_id]}04"/>
    </rpminfo_test>
'''

ver_state_linux_l='''
<dpkginfo_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:ste:15{data[ver_id]}02" version="1" operator="AND" comment="State for Splunk Enterprise version is less than or equal to {data[ver]} (DPKG)" deprecated="false">
      <version entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="less than or equal" mask="false">{data[ver]}</version>
    </dpkginfo_state>
    <rpminfo_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:ste:16{data[ver_id]}02" version="1" operator="AND" comment="State for Splunk Enterprise version is less than or equal to {data[ver]} (RPM)" deprecated="false">
      <version entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="less than or equal" mask="false">{data[ver]}</version>
    </rpminfo_state>
'''
ver_state_linux_e='''
<dpkginfo_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:ste:15{data[ver_id]}00" version="1" operator="AND" comment="State for Splunk Enterprise version is equals to {data[ver]} (DPKG)" deprecated="false">
      <version entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="equals" mask="false">{data[ver]}</version>
    </dpkginfo_state>
    <rpminfo_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:ste:16{data[ver_id]}00" version="1" operator="AND" comment="State for Splunk Enterprise version is equals to {data[ver]} (RPM)" deprecated="false">
      <version entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="equals" mask="false">{data[ver]}</version>
    </rpminfo_state>
'''
ver_state_linux_g='''
<dpkginfo_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:ste:15{data[ver_id]}04" version="1" operator="AND" comment="State for Splunk Enterprise version is greater than or equal to {data[ver]} (DPKG)" deprecated="false">
      <version entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[ver]}</version>
    </dpkginfo_state>
    <rpminfo_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#linux" id="oval:org.tanium.unix.splunk.cve:ste:16{data[ver_id]}04" version="1" operator="AND" comment="State for Splunk Enterprise version is greater than or equal to {data[ver]} (RPM)" deprecated="false">
      <version entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[ver]}</version>
    </rpminfo_state>
'''

# MacOS
criterion_macos_l='''
<criterion test_ref="oval:org.tanium.macos.splunk.cve:tst:11{data[ver_id]}02" negate="false" comment="Check for Splunk Enterprise affected version is less than or equal to {data[ver]}"/>
'''
criterion_macos_e='''
<criterion test_ref="oval:org.tanium.macos.splunk.cve:tst:11{data[ver_id]}00" negate="false" comment="Check for Splunk Enterprise affected version is equals to {data[ver]}"/>
'''
criterion_macos_g='''
<criterion test_ref="oval:org.tanium.macos.splunk.cve:tst:11{data[ver_id]}04" negate="false" comment="Check for Splunk Enterprise affected version is greater than or equal to {data[ver]}"/>
'''

ver_test_macos_l = '''
<textfilecontent54_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.splunk.cve:tst:11{data[ver_id]}02" version="1" check_existence="at_least_one_exists" check="all" state_operator="AND" comment="Check for Splunk Enterprise affected version is less than or equal to {data[ver]}" deprecated="false">
      <object object_ref="oval:org.tanium.macos.splunk.cve:obj:5000"/>
      <state state_ref="oval:org.tanium.macos.splunk.cve:ste:11{data[ver_id]}02"/>
    </textfilecontent54_test>
'''
ver_test_macos_e = '''
<textfilecontent54_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.splunk.cve:tst:11{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="all" state_operator="AND" comment="Check for Splunk Enterprise affected version is equals to {data[ver]}" deprecated="false">
      <object object_ref="oval:org.tanium.macos.splunk.cve:obj:5000"/>
      <state state_ref="oval:org.tanium.macos.splunk.cve:ste:11{data[ver_id]}00"/>
    </textfilecontent54_test>
'''
ver_test_macos_g = '''
<textfilecontent54_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.splunk.cve:tst:11{data[ver_id]}04" version="1" check_existence="at_least_one_exists" check="all" state_operator="AND" comment="Check for Splunk Enterprise affected version is greater than or equal to {data[ver]}" deprecated="false">
      <object object_ref="oval:org.tanium.macos.splunk.cve:obj:5000"/>
      <state state_ref="oval:org.tanium.macos.splunk.cve:ste:11{data[ver_id]}04"/>
    </textfilecontent54_test>
'''

ver_state_macos_l='''
<textfilecontent54_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.splunk.cve:ste:11{data[ver_id]}02" version="1" operator="AND" comment="State for Splunk Enterprise version is less than or equal to {data[ver]}" deprecated="false">
      <subexpression entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="less than or equal" mask="false">{data[ver]}</subexpression>
    </textfilecontent54_state>
'''
ver_state_macos_e='''
<textfilecontent54_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.splunk.cve:ste:11{data[ver_id]}00" version="1" operator="AND" comment="State for Splunk Enterprise version is equals to {data[ver]}" deprecated="false">
      <subexpression entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="equals" mask="false">{data[ver]}</subexpression>
    </textfilecontent54_state>
'''
ver_state_macos_g='''
<textfilecontent54_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.splunk.cve:ste:11{data[ver_id]}04" version="1" operator="AND" comment="State for Splunk Enterprise version is greater than or equal to {data[ver]}" deprecated="false">
      <subexpression entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[ver]}</subexpression>
    </textfilecontent54_state>
'''

class Splunk():
    def __init__(self, cve: str):
        self.cve = cve
        cve_info = cveprey.CVE(cve)
        cve_info.get_nvd_data()
        self.desc = cve_info.nvd_data.description
        self.adv_url = [link for link in cve_info.nvd_data.adv_links if "advisory.splunk.com" in link][0]

        template = open('/home/sujan/OVAL/src/tmp/win-splunk.tmp', 'r')
        template_windows = template.read()
        template.close()

        template = open('/home/sujan/OVAL/src/tmp/lin-splunk.tmp', 'r')
        template_linux = template.read()
        template.close()

        template = open('/home/sujan/OVAL/src/tmp/macos-splunk.tmp', 'r')
        template_macos = template.read()
        template.close()

        adv = cveprey.splunkAdvisories(self.adv_url)
        try:
            versions = adv.versions['Splunk Enterprise']
            for version in versions:
                    tmp_crierions = ''
                    tmp_tests= ''
                    tmp_states = ''
                    global criteria_windows, tests_windows, states_windows
                    global criteria_linux, tests_linux, states_linux
                    global criteria_macos, tests_macos, states_macos
                    if 'to' in version:
                        tmp_version = version.split(' to ')
                        if len(tmp_version)>1:
                            # Windows
                            tmp_crierions += criterion_windows_g.format(data={'ver': tmp_version[0], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[0].split('.')])})
                            tmp_crierions += criterion_windows_l.format(data={'ver': tmp_version[1], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[1].split('.')])})

                            tmp_tests += ver_test_windows_g.format(data={'ver': tmp_version[0], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[0].split('.')])})
                            tmp_tests += ver_test_windows_l.format(data={'ver': tmp_version[1], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[1].split('.')])})

                            tmp_states += ver_state_windows_g.format(data={'ver': tmp_version[0], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[0].split('.')])})
                            tmp_states += ver_state_windows_l.format(data={'ver': tmp_version[1], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[1].split('.')])})
                            tmp_criteria_AND = criteria_AND.format(data={'pat': version, 'criterions': tmp_crierions})
                            criteria_windows += tmp_criteria_AND
                            tests_windows += tmp_tests
                            states_windows += tmp_states
                            # Linux
                            tmp_crierions = ''
                            tmp_tests= ''
                            tmp_states = ''
                            tmp_crierions += criteria_full_linux_g_l.format(data={'pat': version, 'ver_1': tmp_version[0], 'ver_id_1': "".join([f'{v:0>2}' for v in tmp_version[0].split('.')]), 'ver_2': tmp_version[1], 'ver_id_2': "".join([f'{v:0>2}' for v in tmp_version[1].split('.')])})
                            # tmp_crierions += criterion_linux_l.format(data={'ver': tmp_version[1], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[1].split('.')])})

                            tmp_tests += ver_test_linux_g.format(data={'ver': tmp_version[0], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[0].split('.')])})
                            tmp_tests += ver_test_linux_l.format(data={'ver': tmp_version[1], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[1].split('.')])})

                            tmp_states += ver_state_linux_g.format(data={'ver': tmp_version[0], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[0].split('.')])})
                            tmp_states += ver_state_linux_l.format(data={'ver': tmp_version[1], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[1].split('.')])})
                            criteria_linux += tmp_crierions
                            tests_linux += tmp_tests
                            states_linux += tmp_states
                            # MacOS
                            tmp_crierions = ''
                            tmp_tests= ''
                            tmp_states = ''
                            tmp_crierions += criterion_macos_g.format(data={'ver': tmp_version[0], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[0].split('.')])})
                            tmp_crierions += criterion_macos_l.format(data={'ver': tmp_version[1], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[1].split('.')])})

                            tmp_tests += ver_test_macos_g.format(data={'ver': tmp_version[0], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[0].split('.')])})
                            tmp_tests += ver_test_macos_l.format(data={'ver': tmp_version[1], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[1].split('.')])})

                            tmp_states += ver_state_macos_g.format(data={'ver': tmp_version[0], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[0].split('.')])})
                            tmp_states += ver_state_macos_l.format(data={'ver': tmp_version[1], 'ver_id': "".join([f'{v:0>2}' for v in tmp_version[1].split('.')])})
                            tmp_criteria_AND = criteria_AND.format(data={'pat': version, 'criterions': tmp_crierions})
                            criteria_macos += tmp_criteria_AND
                            tests_macos += tmp_tests
                            states_macos += tmp_states
                    else:
                        tmp_crierions += criterion_windows_e.format(data={'ver': version, 'ver_id': "".join([f'{v:0>2}' for v in version.split('.')])})

                        tmp_tests += ver_test_windows_e.format(data={'ver': version, 'ver_id': "".join([f'{v:0>2}' for v in version.split('.')])})

                        tmp_states += ver_state_windows_e.format(data={'ver': version, 'ver_id': "".join([f'{v:0>2}' for v in version.split('.')])})
                        criteria_windows += tmp_crierions
                        tests_windows += tmp_tests
                        states_windows += tmp_states
                        # Linux
                        tmp_crierions = ''
                        tmp_tests= ''
                        tmp_states = ''
                        tmp_crierions += criterion_linux_e.format(data={'ver': version, 'ver_id': "".join([f'{v:0>2}' for v in version.split('.')])})

                        tmp_tests += ver_test_linux_e.format(data={'ver': version, 'ver_id': "".join([f'{v:0>2}' for v in version.split('.')])})

                        tmp_states += ver_state_linux_e.format(data={'ver': version, 'ver_id': "".join([f'{v:0>2}' for v in version.split('.')])})
                        criteria_linux += tmp_crierions
                        tests_linux += tmp_tests
                        states_linux += tmp_states
                        # MacOS
                        tmp_crierions = ''
                        tmp_tests= ''
                        tmp_states = ''
                        tmp_crierions += criterion_macos_e.format(data={'ver': version, 'ver_id': "".join([f'{v:0>2}' for v in version.split('.')])})

                        tmp_tests += ver_test_macos_e.format(data={'ver': version, 'ver_id': "".join([f'{v:0>2}' for v in version.split('.')])})

                        tmp_states += ver_state_macos_e.format(data={'ver': version, 'ver_id': "".join([f'{v:0>2}' for v in version.split('.')])})
                        criteria_macos += tmp_crierions
                        tests_macos += tmp_tests
                        states_macos += tmp_states
            
            data = {
                 'cve': self.cve,
                 'cve_raw': "".join(cve.split('-')[1::]),
                 'title': adv.title,
                 'adurl': self.adv_url,
                 'adid': adv.adv_id,
                 'desc': self.desc,
                 'criteria': criteria_windows,
                 'tests': tests_windows,
                 'states': states_windows
            }
            writer = open(f'{cve}-win-splunk.xml', 'w')
            content = template_windows.format(data=data)
            writer.write(content)
            writer.close()
            data = {
                 'cve': self.cve,
                 'cve_raw': "".join(cve.split('-')[1::]),
                 'title': adv.title,
                 'adurl': self.adv_url,
                 'adid': adv.adv_id,
                 'desc': self.desc,
                 'criteria': criteria_linux,
                 'tests': tests_linux,
                 'states': states_linux
            }
            writer = open(f'{cve}-lin-splunk.xml', 'w')
            content = template_linux.format(data=data)
            writer.write(content)
            writer.close()
            data = {
                 'cve': self.cve,
                 'cve_raw': "".join(cve.split('-')[1::]),
                 'title': adv.title,
                 'adurl': self.adv_url,
                 'adid': adv.adv_id,
                 'desc': self.desc,
                 'criteria': criteria_macos,
                 'tests': tests_macos,
                 'states': states_macos
            }
            writer = open(f'{cve}-macos-splunk.xml', 'w')
            content = template_macos.format(data=data)
            writer.write(content)
            writer.close()
        except Exception as err:
            print(err)

Splunk(sys.argv[1])