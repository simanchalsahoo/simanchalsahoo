import cveprey
import re
_driver = cveprey.oraclePatches()
cve = input("enter the CVE number:")
cve_info = cveprey.CVE(cve)
cve_info.get_nvd_data()
adv = cveprey.oracleAdvisories([cve_info.nvd_data.adv_links[0]], cve=cve)
_driver._init_patch_session("skokkanthi@loginsoft.com", "OS@login123")
strings = _driver._getPatchstrings(cve, adv.patch_links['GoldenGate'])
_driver.driver.quit()
strings = "".join(strings)
patch_numbers = re.findall(r'Patch (\d+)[\s\-]+Oracle GoldenGate ([\d\.]+) for Oracle ([\d\.A-Za-z]+)', strings)
for patch_number in patch_numbers:
    print(patch_number)

