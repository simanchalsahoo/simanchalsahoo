import cveprey, pandas as pd

criteria_mac = '''
<criteria operator="AND" negate="false" comment="Check for {data[ver]}">
            <criterion test_ref="oval:org.tanium.macos.oracle.coherence.cve:tst:614{data[ver_id]}00" negate="false" comment="Check for Oracle Coherence for macOS affected version equal to {data[ver]}"/>
            <criterion test_ref="oval:org.tanium.macos.oracle.coherence.cve:tst:614{data[pat]}04" negate="true" comment="Check for Oracle Coherence for macOS affected patch greater than or equal to {data[pat]}"/>
          </criteria>
'''

patch_test_mac = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.oracle.coherence.cve:tst:614{data[pat]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Coherence for macOS affected patch greater than or equal to {data[pat]}" deprecated="false">
      <object object_ref="oval:org.tanium.macos.oracle.coherence.cve:obj:61400{data[ver_id]}00"/>
      <state state_ref="oval:org.tanium.macos.oracle.coherence.cve:ste:14{data[pat]}04"/>
    </xmlfilecontent_test>
'''
version_test_mac = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.oracle.coherence.cve:tst:614{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="OR" comment="Check for Oracle Coherence for macOS affected version equal to {data[ver]}" deprecated="false">
      <object object_ref="oval:org.tanium.macos.oracle.coherence.cve:obj:1002"/>
      <state state_ref="oval:org.tanium.macos.oracle.coherence.cve:ste:14{data[ver_id]}00"/>
    </xmlfilecontent_test>
'''

patch_obj_mac = '''
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.oracle.coherence.cve:obj:61400{data[ver_id]}00" version="1" comment="Object that collects installed patch version for {data[ver]}" deprecated="false">
      <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.macos.oracle.coherence.cve:var:1003" var_check="at least one"/>
      <xpath datatype="string" operation="equals" mask="false">//*[//component[contains(@internal_name, "oracle.coherence") and @version="{data[ver]}"] and (name()="patch_id" or name()="reference_id")]/@number</xpath>
      <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.coherence.cve:ste:1000</filter>
    </xmlfilecontent_object>
'''

patch_state_mac = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.oracle.coherence.cve:ste:14{data[pat]}04" version="1" operator="AND" comment="State for Oracle Coherence patch greater than equal to {data[pat]}" deprecated="false">
      <value_of entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[pat]}</value_of>
    </xmlfilecontent_state>
'''
version_state_mac = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.macos.oracle.coherence.cve:ste:14{data[ver_id]}00" version="1" operator="AND" comment="State for Oracle Coherence is equals {data[ver]}" deprecated="false">
      <value_of entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="equals" mask="false">{data[ver]}</value_of>
    </xmlfilecontent_state>
'''

# patch = cveprey.oraclePatches()
# patch._init_patch_session("skokkanthi@loginsoft.com", "OS@login123")

patch = pd.read_excel('/home/sujan/Downloads/Coherence_patch.xlsx')
patch = patch.fillna('00')
patch[patch.columns[1::]] = patch[patch.columns[1::]].astype('int')

class oracleCoherence():
    def __init__(self, cve) -> None:
        self.cve = cve
        self.cve_info = cveprey.CVE(cve)
        self.cve_info.get_nvd_data()
        adv_links = [link for link in self.cve_info.nvd_data.adv_links if "oracle.com/security-alerts" in link]
        if len(adv_links) == 0:
            adv_links = [input("Please Input Advisory Url : ")]
        patches = patch[patch.CVE==self.cve]
        try:
            self.adv = cveprey.oracleAdvisories(adv_links, cve)
            versions = self.adv.versions['Fusion Middleware']
        except KeyError:
            _cve = input("Enter Addressed CVE : ")
            self.adv = cveprey.oracleAdvisories(adv_links, _cve)
            versions = self.adv.versions['Fusion Middleware']

        self.real_patches = {}

        for ver in versions:
            try:
                self.real_patches[ver] = patches[ver].item()
            except KeyError:
                self.real_patches[ver] = 0

        print(self.real_patches)

    def macGen(self):
        criteria = ''
        tests = ''
        objects = ''
        states = ''

        for key, value in self.real_patches.items():
            data = {
                'ver': key,
                'pat': value,
                'ver_id': "".join([f'{_ver:0>2}' for _ver in key.split('.')])
            }
            criteria += criteria_mac.format(data=data)
            tests += version_test_mac.format(data=data)
            states += version_state_mac.format(data=data)
            if value != 0:
                tests += patch_test_mac.format(data=data)
                objects += patch_obj_mac.format(data=data)
                states += patch_state_mac.format(data=data)

        data = {
            'cve': self.cve,
            'cve_raw': "".join(self.cve.split('-')[1::]),
            'desc': self.cve_info.nvd_data.description,
            'criteria': criteria,
            'tests': tests,
            'objects': objects,
            'states': states,
            'adurl': '',
            'adid': ''
        }
        fp = open('macos-oracle-coherence.xml.tmp', 'r')
        tmplate_macos = fp.read()
        fp.close()
        fp = open(f'{self.cve}-macos-coherence.xml', 'w')
        contents = tmplate_macos.format(data=data)
        fp.write(contents)
        fp.close()

#"CVE-2020-14756", "CVE-2020-2555", "CVE-2020-2915", "CVE-2020-2949", "CVE-2021-21409", "CVE-2021-2277", "CVE-2021-2344", "CVE-2021-2371", "CVE-2021-2428", "CVE-2021-37136", "CVE-2021-43797", "CVE-2022-21420", "CVE-2022-21570", 
cves = ["CVE-2023-26049"]

for cve in cves:
    oracleCoherence(cve).macGen()