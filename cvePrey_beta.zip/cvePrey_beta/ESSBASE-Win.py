import cveprey, re

crit_OR = '''
<criteria operator="OR" comment="Check for affected Versions and patches">
    {data[versions_criterion]}
    {data[pat_criterion]}
</criteria>
'''
ver_pat_criteria = '''
<criteria operator="AND" comment="Check for {data[version]} and {data[pat]}">
    <criterion test_ref="oval:org.tanium.windows.oracle.essbase.cve:tst:14{data[version_raw]}05" negate="false" comment="Check for Oracle Essbase for Windows version is equal to {data[version]} (newer version)"/>
    <criterion test_ref="oval:org.tanium.windows.oracle.essbase.cve:tst:14{data[pat]}04" negate="true" comment="Check for Oracle Essbase for Windows patch greater than or equal to {data[pat]} (newer version)"/>
</criteria>'''

single_ver = '''
<criterion test_ref="oval:org.tanium.windows.oracle.essbase.cve:tst:14{data[version_raw]}05" negate="false" comment="Check for Oracle Essbase for Windows version equals to {data[version]}"/>\n
'''

ver_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.essbase.cve:tst:14{data[version_raw]}05" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Essbase for Windows version equals to {data[version]}" deprecated="false">
    <object object_ref="oval:org.tanium.windows.oracle.essbase.cve:obj:1001"/>
    <state state_ref="oval:org.tanium.windows.oracle.essbase.cve:ste:14{data[version_raw]}05"/>
</xmlfilecontent_test>\n
'''

pat_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.essbase.cve:tst:14{data[pat]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Windows version {data[version]} Patches greater than or equal to {data[pat]}" deprecated="false">
    <object object_ref="oval:org.tanium.windows.oracle.essbase.cve:obj:142100"/>
    <state state_ref="oval:org.tanium.windows.oracle.essbase.cve:ste:14{data[pat]}04"/>
</xmlfilecontent_test>\n'''
 
ver_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.essbase.cve:ste:14{data[version_raw]}05" version="1" operator="AND" comment="State for Essbase is {data[version]}" deprecated="false">
    <value_of entity_check="all" check_existence="at_least_one_exists" datatype="string" operation="pattern match" mask="false">^{data[version_pat]}.*$</value_of>
</xmlfilecontent_state>\n'''

pat_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.essbase.cve:ste:14{data[pat]}04" version="1" operator="AND" comment="State for Essbase 11g is greater than or equal to {data[pat]} patches" deprecated="false">
    <value_of entity_check="at least one" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[pat]}</value_of>
</xmlfilecontent_state>\n'''


patch_driver = cveprey.oraclePatches()
patch_driver._init_patch_session("skokkanthi@loginsoft.com", "OS@login123")

class Essbase():
    r'''
    Oracle Essbase
    '''
    def __init__(self, cve:str):
        self.cve = cve
        self.criteria = ""
        self.tests = ""
        self.pat_tests = ""
        self.pat_objects = ""
        self.states = ""
        self.pat_states = ""
        cve_info = cveprey.CVE(cve)
        cve_info.get_nvd_data()
        self.desc = cve_info.nvd_data.description
        try:
            self.title = re.findall(r"([Vv]ulnerability[^\d].*\(component\:[^\d]+\))", self.desc)[0]
        except IndexError:
            self.title = ""
        links = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link]
        adv = cveprey.oracleAdvisories(links, cve=cve, comp="Essbase")
        print(adv.component)
        if adv.addressed:
            print(adv.component)
        print(adv.versions)
        self.adv_link = [key for key in adv.adv_links.keys() if 'Essbase' in adv.adv_links[key]][0]
        # print(self.adv_link)
        # print(adv.patch_links['Essbase'])
        if adv.addressed:
            cve = adv.addressed_cve
        strings = patch_driver._getPatchstrings(cve, adv.patch_links['Essbase'])
        if len(strings) == 0:
            patch_string = list()
            content = patch_driver.driver.get(adv.patch_links['Essbase'][0])
            contents = patch_driver.driver.page_source
            root = cveprey._core.lhtml.fromstring(contents)
            strings = root.xpath(f'//table[@rules="all"]//tr[.//*[contains(.//text(),"ESSBASE")]]')
            patch_string.extend([" ".join(" ".join(i.xpath('.//text()')).split('\n')) for i in strings])
            if len(patch_string) == 0:
                strings = root.xpath(f'//table//tr[contains(.//text(),"ESSBASE")]')
                patch_string.extend([" ".join(" ".join(i.xpath('.//text()')).split('\n')) for i in strings])
            strings = patch_string
        #print(strings)
        patch_numbers = re.findall(r'([\w\.]+)\s*ORACLE\s*ESSBASE\s*([A-Za-z]+)\s*([A-Za-z]+)\s*Patch\s*(\d+)', "".join(strings))
        print(patch_numbers)
        try:
            print(adv.versions)
            versions = list(map(lambda x: '.'.join(x.split('.')[:-1]) if len(x.split('.'))>4 else x, adv.versions['Essbase']))
            self.writeCVE(versions, patch_numbers)
        except Exception:
            adid = re.findall(r"/(cpu[a-zA-Z0-9]+).*html", self.adv_link)[0].lower()
            _cvrf = cveprey.oracleCVRF()
            _adv = _cvrf._CVE(cve=cve, adid=adid)
            self.writeCVE(_cvrf.affected_version['Essbase'])

    def writeCVE(self, versions:list=None, patches=list):
        patch_dic = {}
        _file_ = 'ESSBASE-Win-template.xml'

        tmp = open(_file_, 'r')
        content_read = tmp.read()
        tmp.close()
        tmp = open(f'{self.cve.upper()}-win-oracle.essbase.xml', 'w')
        for version in versions:
            patch_dic[version] = {}
            for patch in patches:
                patch_dic[version] = [patch[3] for patch in patches]
                if len(patch_dic[version])<1:
                    patch_dic[version] = [patch[3] for patch in patches] 
        print(patch_dic)
        self.buildData(patch_dic)
        data = {
            'cve': self.cve,
            'cve_raw': "".join(self.cve.split('-')[1::]),
            'title': self.title,
            'adv_link': self.adv_link[0],
            'adid': re.findall(r"/(cpu.*).html", self.adv_link)[0].upper(),
            'adid_r': re.findall(r"/(cpu.*).html", self.adv_link)[0],
            'desc': self.desc,
            'criteria': self.criteria,
            'versions_tests': self.tests,
            'pat_tests': self.pat_tests,
            'version_states': self.states,
            'pat_objects': self.pat_objects,
            'pat_states': self.pat_states
        }
        content_read = content_read.format(data=data)
        tmp.write(content_read)
        tmp.close()

    def buildData(self, patch_dic):
        for version in patch_dic.keys():
            version=".".join(version.split('.')[:-1]) if len(version.split('.'))>4 else version
            version_raw = "".join([f'{ver:0>2}' for ver in version.split('.')])
            data_1 = {
                'version_raw': version_raw,
                'version': version,
                'version_pat': "\.".join(version.split(".")[:-1]) if len(version.split('.'))>4 else "\.".join(version.split("."))
            }
            self.tests += ver_test.format(data=data_1)
            self.states += ver_state.format(data=data_1)
            if len(patch_dic[version])>0:
                data_1 = {
                'version_raw': version_raw,
                'pat': patch_dic[version][0],
                'version': ".".join(version.split(".")[:-1]) if len(version.split('.'))>4 else ".".join(version.split("."))
                }
                self.criteria += ver_pat_criteria.format(data=data_1)
                self.tests += pat_test.format(data=data_1)
                self.states += pat_state.format(data=data_1)

            else:
                data_1 = {
                'version_raw': version_raw,
                'version': ".".join(version.split(".")[:-1]) if len(version.split('.'))>4 else ".".join(version.split("."))
                }
                self.criteria += single_ver.format(data=data_1)
            
            

with open('examples.txt', 'r') as file:
     data = file.read().split()


for cve in data:
    print(cve)
    Essbase(cve)
patch_driver.driver.quit()