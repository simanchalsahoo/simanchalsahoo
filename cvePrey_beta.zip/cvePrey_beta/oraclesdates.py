import cveprey, sys

months = {'Jan':'01', 'Apr':'04', 'July':'07', 'Oct':'10'}
_months = list(months.keys())
_dates = list(months.values())

fp = open(sys.argv[1], 'r')
contents = fp.read()
fp.close()

url = "https://www.oracle.com/security-alerts/cpu{data[mnth]}{data[yr]}.html"

root = cveprey._core.lhtml.fromstring(contents.encode('utf-8'))
year = cveprey._core.re.findall(r'cpu(.*)-?', root.xpath('.//reference[@source="VENDOR"]/@ref_id')[0])[0]
month = cveprey._core.re.findall(r'([A-Za-z]+)', year)[0]
month = month.replace(month[0], month[0].upper())
year = cveprey._core.re.findall(r'([\d]+)', year)[0]

if month == _months[0]:
    tmp_month = _months[_months.index(month)-1]
    tmp_year = int(year)-1
else:
    tmp_year = int(year)
    tmp_month = _months[_months.index(month)-1]

data = {
        'mnth': tmp_month,
        'yr': tmp_year
        }

url = url.format(data=data)
parsedContent = cveprey._core.CVENetTools.get(url)
root1 = cveprey._core.lhtml.fromstring(parsedContent.encode('utf-8'))

adv_dates = root1.xpath('.//ul[@class="obullets"][./preceding-sibling::h3[contains(text(), "Patch Update Schedule")]]')[0]
for i in adv_dates.xpath('.//li//text()'):
    if month in i:
        col = (i.split())
        _mnth = months[month]
        _year = col[-1][-2:]
        _date = col[0]
        final = str(_year)+str(_mnth)+str(_date)

print(final)
tmp = root.xpath(f'.//subexpression[not(contains(./text(), "{final}"))]/text()')

for i in tmp:
    print(i)



