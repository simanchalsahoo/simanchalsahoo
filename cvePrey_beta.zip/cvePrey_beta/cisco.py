import cveprey, sys

cve_info = cveprey.CVE(sys.argv[1])
cve_info.get_nvd_data()
print(cve_info.nvd_data.product)
# adv = cveprey.ciscoAdvisories(cve_info.cve_id, cve_info.nvd_data.adv_links[1])
# cvrf = adv.cvrf_contents()

# print(cvrf.affected_versions)