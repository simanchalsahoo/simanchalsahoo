import cveprey, sys, re

single_ver = '''
<criterion test_ref="oval:org.tanium.unix.oracle.goldengate.cve:tst:714{data[version_raw]}00" negate="false" comment="Check for Oracle GoldenGate 11g for Linux version equals to {data[version]}"/>\n
<criterion test_ref="oval:org.tanium.unix.oracle.goldengate.cve:tst:814{data[version_raw]}00" negate="false" comment="Check for Oracle GoldenGate 12c for Linux version equals to {data[version]}"/>\n'''

ver_pat_crit_11 = '''
<criteria operator="AND" negate="false" comment="version for {data[version]} for 11g">
    <criterion test_ref="oval:org.tanium.unix.oracle.goldengate.cve:tst:714{data[version_raw]}00" negate="false" comment="Check for goldengate 11g for Linux version equals to {data[version]}"/>
    <criterion test_ref="oval:org.tanium.unix.oracle.goldengate.cve:tst:714{data[pat]}04" negate="true" comment="Check for goldengate 11g for Linux version {data[version]} Patches greater than or equal to {data[pat]}"/>
</criteria>\n'''
ver_pat_crit_12= '''
<criteria operator="AND" negate="false" comment="version for {data[version]} for 12c">
    <criterion test_ref="oval:org.tanium.unix.oracle.goldengate.cve:tst:814{data[version_raw]}00" negate="false" comment="Check for goldengate 12c for Linux version equals to {data[version]}"/>
    <criterion test_ref="oval:org.tanium.unix.oracle.goldengate.cve:tst:814{data[pat]}04" negate="true" comment="Check for goldengate 12c for Linux version {data[version]} Patches greater than or equal to {data[pat]}"/>
</criteria>\n'''

ver_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.goldengate.cve:tst:714{data[version_raw]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for goldengate 11g for Linux version equals to {data[version]}" deprecated="false">
    <object object_ref="oval:org.tanium.unix.oracle.goldengate.cve:obj:1002"/>
    <state state_ref="oval:org.tanium.unix.oracle.goldengate.cve:ste:14{data[version_raw]}00"/>
</xmlfilecontent_test>\n
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.goldengate.cve:tst:814{data[version_raw]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for goldengate 12c for Linux version equals to {data[version]}" deprecated="false">
    <object object_ref="oval:org.tanium.unix.oracle.goldengate.cve:obj:1003"/>
    <state state_ref="oval:org.tanium.unix.oracle.goldengate.cve:ste:14{data[version_raw]}00"/>
</xmlfilecontent_test>\n'''

pat_test_11 = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.goldengate.cve:tst:14{data[pat]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for goldengate 11g for Linux version {data[version]} Patches greater than or equal to {data[pat]}" deprecated="false">
    <object object_ref="oval:org.tanium.unix.oracle.goldengate.cve:obj:14{data[version_raw]}00"/>
    <state state_ref="oval:org.tanium.unix.oracle.goldengate.cve:ste:14{data[pat]}04"/>
</xmlfilecontent_test>\n'''

pat_test_12='''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.goldengate.cve:tst:14{data[pat]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for goldengate 12c for Linux version {data[version]} Patches greater than or equal to {data[pat]}" deprecated="false">
    <object object_ref="oval:org.tanium.unix.oracle.goldengate.cve:obj:14{data[version_raw]}00"/>
    <state state_ref="oval:org.tanium.unix.oracle.goldengate.cve:ste:14{data[pat]}04"/>
</xmlfilecontent_test>\n'''

pat_object='''
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.goldengate.cve:obj:14{data[version_raw]}00" version="1" comment="Object that collects installed patch version " deprecated="false">
    <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.unix.oracle.goldengate.cve:var:1004" var_check="at least one"/>
    <xpath datatype="string" operation="equals" mask="false">//patch_id[//required_components/component[contains(@internal_name, "oracle.oggcore.ora12c") or (contains(@internal_name, "oracle.oggcore.ora11g") and contains(@version, "{data[version]}"))]]/@number | //reference_id[//required_components/component[contains(@internal_name, "oracle.oggcore.ora12c") or (contains(@internal_name, "oracle.oggcore.ora11g") and contains(@version, "{data[version]}"))]]/@number</xpath>
    <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.goldengate.cve:ste:1000</filter>
</xmlfilecontent_object>
'''
 
ver_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.goldengate.cve:ste:14{data[version_raw]}00" version="1" operator="AND" comment="State for goldengate is equals to {data[version]}" deprecated="false">
    <value_of entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="equals" mask="false">{data[version]}</value_of>
</xmlfilecontent_state>\n'''

pat_state_11 = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.goldengate.cve:ste:14{data[pat]}04" version="1" operator="AND" comment="State for goldengate 11g is greater than or equal to {data[pat]} patches" deprecated="false">
    <value_of entity_check="at least one" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[pat]}</value_of>
</xmlfilecontent_state>\n'''
pat_state_12='''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.goldengate.cve:ste:14{data[pat]}04" version="1" operator="AND" comment="State for goldengate 12c is greater than or equal to {data[pat]} patches" deprecated="false">
    <value_of entity_check="at least one" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[pat]}</value_of>
</xmlfilecontent_state>\n'''

patch_driver = cveprey.oraclePatches()
patch_driver._init_patch_session("skokkanthi@loginsoft.com", "OS@login123")

class OGG():
    r'''
    Oracle E-Business Suite
    '''
    def __init__(self, cve:str):
        self.cve = cve
        self.criteria = ""
        self.tests = ""
        self.pat_tests = ""
        self.pat_objects = ""
        self.states = ""
        self.pat_states = ""
        cve_info = cveprey.CVE(cve)
        cve_info.get_nvd_data()
        self.desc = cve_info.nvd_data.description
        try:
            self.title = re.findall(r"([Vv]ulnerability.*\s+component)", self.desc)[0]
        except IndexError:
            self.title = ""
        try:
            links = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link]
            if len(links) > 1:
                print("[!] Multiple Advisory Links Found")
                for link in links:
                    print(link)
                t = int(input("Give Index Link of adv to use : "))
                self.adv_link = links[t-1]
            else:
                self.adv_link = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link]
        except IndexError:
            self.adv_link = input("Provide Adv Link : ")
        adv = cveprey.oracleAdvisories(self.adv_link, cve=cve)
        strings = patch_driver._getPatchstrings(self.cve, adv.patch_links['GoldenGate'])
        strings = "".join(strings)
        patch_numbers = re.findall(r'Patch (\d+)[\s\-]+Oracle GoldenGate ([\d\.]+) for Oracle ([\d\.A-Za-z]+)', strings)
        try:
            print(adv.versions)
            self.writeCVE(adv.versions['GoldenGate'], patch_numbers)
        except Exception:
            adid = re.findall(r"/(cpu[a-zA-Z0-9]+).*html", self.adv_link)[0].lower()
            _cvrf = cveprey.oracleCVRF()
            _adv = _cvrf._CVE(cve=cve, adid=adid)
            # print(_cvrf.affected_family)
            self.writeCVE(_cvrf.affected_version['GoldenGate'])

    def writeCVE(self, versions:list=None, patches=list):
        patch_dic = {}
        _file_ = 'OGG-Lin-template.xml'

        tmp = open(_file_, 'r')
        content_read = tmp.read()
        tmp.close()
        tmp = open(f'{self.cve.upper()}-lin-ogg.xml', 'w')
        for version in versions:
            patch_dic[version] = {}
            for patch in patches:
                tag = patch[2]
                patch_dic[version][tag] = [patch[0] for patch in patches if (patch[1].split('.')[:-1] == version.split('.')[:-1]) and (tag == patch[2])] 
        print(patch_dic)
        self.buildData(patch_dic)
        data = {
            'cve': self.cve,
            'cve_raw': "".join(self.cve.split('-')[1::]),
            'title': self.title,
            'adv_link': self.adv_link[0],
            'adid': re.findall(r"/(cpu.*).html", self.adv_link[0])[0].upper(),
            'adid_r': re.findall(r"/(cpu.*).html", self.adv_link[0])[0],
            'desc': self.desc,
            'versions_criterion': self.criteria,
            'versions_tests': self.tests,
            'pat_tests': self.pat_tests,
            'version_states': self.states,
            'pat_objects': self.pat_objects,
            'pat_states': self.pat_states
        }
        content_read = content_read.format(data=data)
        tmp.write(content_read)
        tmp.close()

    def buildData(self, patch_dic):
        for version in patch_dic.keys():
            version_raw = "".join([f'{ver:0>2}' for ver in version.split('.')])
            data_1 = {
                'version_raw': version_raw,
                'version': version
            }
            self.tests += ver_test.format(data=data_1)
            self.states += ver_state.format(data=data_1)
            for tag in patch_dic[version]:
                if len(patch_dic[version][tag])>0:
                    data_1 = {
                        'version_raw': version_raw,
                        'pat': patch_dic[version][tag][0],
                        'version': version
                    }
                    self.pat_objects += pat_object.format(data=data_1)
                    if "11" in tag:
                        self.tests += pat_test_11.format(data=data_1)
                        self.states += pat_state_11.format(data=data_1)
                        self.criteria += ver_pat_crit_11.format(data=data_1)
                    if "12" in tag:
                        self.tests += pat_test_12.format(data=data_1)
                        self.states += pat_state_12.format(data=data_1)
                        self.criteria += ver_pat_crit_12.format(data=data_1)
                else:
                    if version not in self.criteria:
                        self.criteria += single_ver.format(data=data_1)


OGG(sys.argv[1])
patch_driver.driver.quit()