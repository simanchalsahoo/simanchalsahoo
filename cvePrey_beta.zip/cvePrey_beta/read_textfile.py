with open('examples.txt', 'r') as file:
    data = file.read()
print(data)
for i in data:
    data2=print("x")
print(data2)