import cveprey, sys
cve = sys.argv[1]
ciscoAdv = cveprey.ciscoSecurityAdvisories()
adv = cveprey.ciscoAdvisories(cve, ciscoAdv.cveData(cve).adv_link)
cvrf = adv.cvrf_contents()
versions = cvrf.affected_versions
conv = cveprey.ciscoMappingVersions()
for ver in  versions.keys():
    if "IOS XE" in ver:
        versions[ver]['Mapped Versions'] = conv.mapped_iosxe_ios(versions[ver]['All'])

print(versions)
