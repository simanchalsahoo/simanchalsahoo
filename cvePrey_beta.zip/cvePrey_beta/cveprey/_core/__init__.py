# File to make it as a python Package
from .requests import CVENetTools
import lxml.html as lhtml
from .scrapers import *