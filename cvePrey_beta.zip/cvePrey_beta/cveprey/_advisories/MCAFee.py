from .. import _core
import re, json

class McAFee():
    def __init__(self, cve: str, adv_url: str) -> None:
        pass

    @property
    def title(self) -> str:
        pass