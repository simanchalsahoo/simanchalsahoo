from .. import _core
import re, time as _time

class trendMicroAdvisories():
    def __init__(self) -> None:
        pass