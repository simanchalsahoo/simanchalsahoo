from .. import _core

class autodeskAdvisories(object):
    def __init__(self, cve: str, adv_link: str) -> None:
        self._cve = cve
        content = _core.CVENetTools.getGecko(adv_link)
        self.parsed_content = _core.lhtml.fromstring(content)

    @property
    def title(self):
        return "".join(
            list(
                map(
                    lambda x: x if (x.isalnum() or x.isspace()) else '', 
                    self.parsed_content.xpath(f'//*[contains(./text(), "{self._cve}")]/text()')[0].strip()
                    )
                )
        )

    @property
    def versions(self):
        try:
            affected_table = self.parsed_content.xpath('//table[.//th//text()="Item"]')[0]
            versions_row = affected_table.xpath('.//tr[.//td]')
            data = {}
            for row in versions_row:
                _row = row.xpath('./td')
                item = "".join(char for char in "".join(_row[0].xpath('.//text()')) if char.isalnum())
                affected_versions = [ver.strip() for ver in "".join(_row[1].xpath('.//text()')).split(',')]
                fixed_versions = _core.re.findall(r"([\d\.]+)", ",".join([fixed.strip() for fixed in "".join(_row[2].xpath('.//text()')).split(',')]))

                data[item] = {}

                for key in affected_versions:
                    for value in fixed_versions:
                        if key in value:
                            data[item][key] = value
                            break
                        else:
                            data[item][key] = ''
                    continue

            return data
        except IndexError:
            print("Advisory Not Valid")
