from .. import _core
import re

class juniperCEC(object):
    def __init__(self, cve:str):
        cve = ''

    def _none():
        pass

    def cveSearch(self, cve:str):
        pass