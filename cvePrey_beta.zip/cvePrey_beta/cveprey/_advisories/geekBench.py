from .. import _core
import json

HOME_URL = "https://browser.geekbench.com"

class geekBench(object):
    def __init__(self, search_term: str) -> None:
        url = f"https://browser.geekbench.com/search?q={search_term}"
        content = _core.CVENetTools.get(url).lower()
        root = _core.lhtml.fromstring(content.encode())
        try:
            page_url = root.xpath(f'//a[./text()="hp {search_term.lower()}"]/@href')[0]
            self.parse_page(HOME_URL+page_url)
        except IndexError:
            try:
                page_url = root.xpath(f'//a[contains(./text(), "hp {search_term.lower()}")]/@href')[0]
                self.parse_page(HOME_URL+page_url)
            except Exception as err:
                print(err, search_term)
                pass

    def parse_page(self, page_url):
        content = _core.CVENetTools.get(page_url)
        self.parsed_content = _core.lhtml.fromstring(content.encode())

    @property
    def boardNumber(self):
        text = self.parsed_content.xpath(f'//table[contains(@class, "system-table")]//tr[./td[@class="system-name" and ./text()="Motherboard"]]/td[@class="system-value"]/text()')[0]
        return _core.re.findall(r'HP\s*(\S+)', text)[0]