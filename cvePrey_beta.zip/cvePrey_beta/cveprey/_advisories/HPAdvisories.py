from .. import _core
import json

'''
Collect Useful information from HP Security Advisories

Analysis:
    https://support.hp.com/us-en/document/ish_5817864-5817896-16
    https://support.hp.com/us-en/security-bulletins
    https://support.hp.com/us-en/security-bulletin-archive
'''

class HPAdvisories(object):
    def __init__(self, url: str) -> None:
        #url = f"https://support.hp.com/wcc-services/search/us-en/security-bulletins?query={cve}&sortBy=bulletinUpdateDate&sortOrder=desc"
        content = _core.CVENetTools.getGecko(url)
        self.parsed_content = _core.lhtml.fromstring(content.encode())

    @property
    def affected_versions(self):
        _dict = {}
        tables = self.parsed_content.xpath('//table[.//*[@class="tablecap" and contains(.//text(), "Business")]]')
        for table in tables:
            for row in table.xpath('.//tbody/tr'):
                _dict.update({row.xpath('.//text()')[2]:row.xpath('.//text()')[10]})
        
        return _dict

class HPEAdvisories(object):
    def __init__(self) -> None:
        pass