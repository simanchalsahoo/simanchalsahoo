from .. import _core
import re, json

class wso2Advisories(object):
    def __init__(self) -> None:
        pass

    @property
    def title(self):
        pass

    @property
    def affected_versions(self):
        pass