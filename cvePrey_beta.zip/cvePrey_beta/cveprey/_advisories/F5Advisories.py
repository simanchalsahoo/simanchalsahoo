from .. import _core
import re, json

class F5Advisories(object):
    def __init__(self, ad_url: str, cve: str) -> None:
        driver = _core.CVENetTools.getGecko(ad_url)
        self.parsed_content = _core.lhtml.fromstring(driver)
        