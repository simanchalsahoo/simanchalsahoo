from .. import _core

class juniperAdvisories():
    r'''
    Collects CVE information from Juniper Advisory and process its properties
    params:
        url: str

    properties:
        title
        versions_raw
    '''
    def __init__(self, url: str):
        self.url = url
        self.raw_content = _core.CVENetTools.getGecko(self.url)
        self.parsed_object = _core.lhtml.fromstring(self.raw_content)

    @property
    def adid(self):
        try:
            return _core.re.findall(r"(JSA\S*)", self.url)[0]
        except Exception:
            return ""

    @property
    def title(self):
        try:
            return self.parsed_object.xpath('//div[@class="titleSection"]/p/text()')[0]
        except Exception:
            return ""

    @property
    def versions_raw(self):
        regex = _core.re.compile(r">(^\d[\d\.A-Za-z,\s;]+|[^Jj][A-Za-z\s\d\.-]+[\d\.]+[FIXBAR][\d\.]+[-]?[SD]?[A-Za-z\d\.\-\s,;]+)<"                                 )
        versions = regex.findall(self.raw_content)

        return versions

    @property
    def affected_products(self):
        products = self.parsed_object.xpath('//div[contains(@class, "afftedProd")]/a/text()')
        return products
    
    @property
    def prs(self):
        r'''
        get problem report links
        '''
        links = self.parsed_object.xpath('//a[contains(@href, "problemreport")]/@href')
        return links
    

class juniperCEC(object):
    def __init__(self, cve:str):
        cve = ''

    def _none():
        pass

    def cveSearch(self, cve:str):
        pass