from .. import _core

URL = "https://www.nagios.com/products/security/"

class nagiosAdvisories(object):
    def __init__(self, cve: str) -> None:
        self.cve = cve
        