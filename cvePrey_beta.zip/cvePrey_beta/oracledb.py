import cveprey

nvd_info = cveprey.CVE("CVE-2013-5858")
nvd_info.get_nvd_data()
urls_pat = "https://www.oracle.com/security-alerts/cpujan2014.html"
adv = cveprey.oracleAdvisories(nvd_info.cve_id, url)

print(adv.versions)
