import cveprey, sys


class _JavaSE(object):
    def __init__(self) -> None:
        self.cve = sys.argv[1]

_JavaSE()