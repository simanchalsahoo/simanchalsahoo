import cveprey, re

crit_OR = '''
<criteria operator="OR" comment="Check for affected Versions and patches">
    {data[versions_criterion]}
</criteria>
'''

single_ver = '''
<criterion test_ref="oval:org.tanium.windows.oracle.goldengate.cve:tst:14{data[version_raw]}00" negate="false" comment="Check for Oracle GoldenGate for Windows version equals to {data[version]}"/>\n
'''

ver_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.goldengate.cve:tst:14{data[version_raw]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for goldengate for Windows version equals to {data[version]}" deprecated="false">
    <object object_ref="oval:org.tanium.windows.oracle.goldengate.cve:obj:1002"/>
    <state state_ref="oval:org.tanium.windows.oracle.goldengate.cve:ste:14{data[version_raw]}00"/>
</xmlfilecontent_test>\n
'''

pat_test_11 = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.goldengate.cve:tst:14{data[pat]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Windows version {data[version]} Patches greater than or equal to {data[pat]}" deprecated="false">
    <object object_ref="oval:org.tanium.windows.oracle.goldengate.cve:obj:14{data[version_raw]}00"/>
    <state state_ref="oval:org.tanium.windows.oracle.goldengate.cve:ste:14{data[pat]}04"/>
</xmlfilecontent_test>\n'''

pat_test_12='''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.goldengate.cve:tst:814{data[pat]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for goldengate 12c for Windows version {data[version]} Patches greater than or equal to {data[pat]}" deprecated="false">
    <object object_ref="oval:org.tanium.windows.oracle.goldengate.cve:obj:814{data[version_raw]}00"/>
    <state state_ref="oval:org.tanium.windows.oracle.goldengate.cve:ste:14{data[pat]}04"/>
</xmlfilecontent_test>\n'''

pat_object_11='''
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.goldengate.cve:obj:714{data[version_raw]}00" version="1" comment="Object that collects installed patch version for 11g" deprecated="false">
    <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.windows.oracle.goldengate.cve:var:1004" var_check="at least one"/>
    <xpath datatype="string" operation="equals" mask="false">//*[//component[contains(@internal_name, "oracle.oggcore.ora11g") and contains(@version, "{data[version]}")] and (name()="patch_id" or name()="reference_id")]/@number</xpath>
    <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.windows.oracle.goldengate.cve:ste:1000</filter>
</xmlfilecontent_object>
'''
pat_object_12='''
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.goldengate.cve:obj:814{data[version_raw]}00" version="1" comment="Object that collects installed patch version for 12c" deprecated="false">
    <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.windows.oracle.goldengate.cve:var:1004" var_check="at least one"/>
    <xpath datatype="string" operation="equals" mask="false">//*[//component[contains(@internal_name, "oracle.oggcore.ora12c") and contains(@version, "{data[version]}")] and (name()="patch_id" or name()="reference_id")]/@number</xpath>
    <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.windows.oracle.goldengate.cve:ste:1000</filter>
</xmlfilecontent_object>
'''
 
ver_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.goldengate.cve:ste:14{data[version_raw]}00" version="1" operator="AND" comment="State for goldengate is equals to {data[version]}" deprecated="false">
    <value_of entity_check="all" check_existence="at_least_one_exists" datatype="string" operation="pattern match" mask="false">^{data[version_pat]}.*$</value_of>
</xmlfilecontent_state>\n'''

pat_state_11 = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.goldengate.cve:ste:14{data[pat]}04" version="1" operator="AND" comment="State for goldengate 11g is greater than or equal to {data[pat]} patches" deprecated="false">
    <value_of entity_check="at least one" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[pat]}</value_of>
</xmlfilecontent_state>\n'''

pat_state_12='''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.goldengate.cve:ste:14{data[pat]}04" version="1" operator="AND" comment="State for goldengate 12c is greater than or equal to {data[pat]} patches" deprecated="false">
    <value_of entity_check="at least one" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[pat]}</value_of>
</xmlfilecontent_state>\n'''


# patch_driver = cveprey.oraclePatches()
# patch_driver._init_patch_session("skokkanthi@loginsoft.com", "OS@login123")

class OGG():
    r'''
    Oracle E-Business Suite
    '''
    def __init__(self, cve:str):
        self.cve = cve
        self.criteria = ""
        self.tests = ""
        self.pat_tests = ""
        self.pat_objects = ""
        self.states = ""
        self.pat_states = ""
        cve_info = cveprey.CVE(cve)
        cve_info.get_nvd_data()
        self.desc = cve_info.nvd_data.description
        try:
            self.title = re.findall(r"([Vv]ulnerability.*\s+component)", self.desc)[0]
        except IndexError:
            self.title = ""
        try:
            links = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link]
            if len(links) > 1:
                print("[!] Multiple Advisory Links Found")
                for link in links:
                    print(link)
                t = int(input("Give Index Link of adv to use : "))
                self.adv_link = links[t-1]
            else:
                self.adv_link = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link]
        except IndexError:
            self.adv_link = input("Provide Adv Link : ")
        adv = cveprey.oracleAdvisories(self.adv_link, cve=cve)
        print(adv.versions)
        try:
            strings = ""
            adv.versions['GoldenGate']
        except KeyError:
            if 'Database Server' in adv.versions.keys():
                adv.versions['GoldenGate'] = adv.versions['Database Server']
                # adv.patch_links['GoldenGate'] = list(set(adv.root.xpath(f'//tbody//tr[contains(.//td//text(), "GoldenGate")]//a/@href[contains(., "support.oracle.com")]')))
                strings = ""
        strings = "".join(strings).lower()
        patch_numbers = re.findall(r'patch (\d+)[\s\-]+oracle goldengate v?([\d\.]+) for oracle ([\d\.A-Za-z]+)', strings)
        print(patch_numbers)
        try:
            print(adv.versions)
            self.writeCVE(adv.versions['GoldenGate'], patch_numbers)
        except Exception:
            adid = re.findall(r"/(cpu[a-zA-Z0-9]+).*html", self.adv_link)[0].lower()
            _cvrf = cveprey.oracleCVRF()
            _adv = _cvrf._CVE(cve=cve, adid=adid)
            self.writeCVE(_cvrf.affected_version['GoldenGate'])

    def writeCVE(self, versions:list=None, patches=list):
        patch_dic = {}
        _file_ = 'OGG-Win-template.xml'

        tmp = open(_file_, 'r')
        content_read = tmp.read()
        tmp.close()
        tmp = open(f'{self.cve.upper()}-win-ogg.xml', 'w')
        for version in versions:
            patch_dic[version] = {}
            for patch in patches:
                tag = patch[2]
                patch_dic[version][tag] = [patch[0] for patch in patches if (version in patch[1]) and (tag == patch[2])]
                if len(patch_dic[version][tag])<1:
                    patch_dic[version][tag] = [patch[0] for patch in patches if (patch[1].split('.')[:-1] == version.split('.')[:-1]) and (tag == patch[2])] 
        print(patch_dic)
        self.buildData(patch_dic)
        data = {
            'cve': self.cve,
            'cve_raw': "".join(self.cve.split('-')[1::]),
            'title': self.title,
            'adv_link': self.adv_link[0],
            'adid': re.findall(r"/(cpu.*).html", self.adv_link[0])[0].upper(),
            'adid_r': re.findall(r"/(cpu.*).html", self.adv_link[0])[0],
            'desc': self.desc,
            'versions_criterion': self.criteria,
            'versions_tests': self.tests,
            'pat_tests': self.pat_tests,
            'version_states': self.states,
            'pat_objects': self.pat_objects,
            'pat_states': self.pat_states
        }
        content_read = content_read.format(data=data)
        tmp.write(content_read)
        tmp.close()

    def buildData(self, patch_dic):
        tmp = ''
        for version in patch_dic.keys():
            version_raw = "".join([f'{ver:0>2}' for ver in version.split('.')])
            data_1 = {
                'version_raw': version_raw,
                'version': version,
                'version_pat': "\.".join(version.split(".")[:-1]) if len(version.split('.'))>4 else "\.".join(version.split("."))
            }
            self.tests += ver_test.format(data=data_1)
            self.states += ver_state.format(data=data_1)
            if len(patch_dic.keys()) == 1:
                self.criteria += single_ver.format(data=data_1)
                tmp = ''
            else:
                tmp += single_ver.format(data=data_1)
        
        if tmp != '':
            self.criteria = crit_OR.format(data={'versions_criterion': tmp})
            

with open('examples.txt', 'r') as file:
    data = file.read().split()

for cve in data:
    OGG(cve)
# patch_driver.driver.quit()