import lxml.html as lhtml, sys, json
import pandas as pd

### Linux ###

ver_test_tmp_l='''
<textfilecontent54_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:tst:711{data[ver_id]}05" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Linux (Docker) version are {data[ver]}" deprecated="false">
  <object object_ref="oval:org.tanium.unix.oracle.database.server.cve:obj:3001"/>
  <state state_ref="oval:org.tanium.unix.oracle.database.server.cve:ste:11{data[ver_id]}05"/>
</textfilecontent54_test>
<textfilecontent54_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:tst:811{data[ver_id]}05" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Linux (Standalone) version are {data[ver]}" deprecated="false">
  <object object_ref="oval:org.tanium.unix.oracle.database.server.cve:obj:1003"/>
  <state state_ref="oval:org.tanium.unix.oracle.database.server.cve:ste:11{data[ver_id]}05"/>
</textfilecontent54_test>
<textfilecontent54_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:tst:911{data[ver_id]}05" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Linux (EM) version are {data[ver]}" deprecated="false">
  <object object_ref="oval:org.tanium.unix.oracle.database.server.cve:obj:2004"/>
  <state state_ref="oval:org.tanium.unix.oracle.database.server.cve:ste:11{data[ver_id]}05"/>
</textfilecontent54_test>'''

patch_test_tmp_l='''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:tst:714{data[ver_id]}{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Linux (Docker) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)" deprecated="false">
  <object object_ref="oval:org.tanium.unix.oracle.database.server.cve:obj:71400{data[ver_id]}00"/>
  <state state_ref="oval:org.tanium.unix.oracle.database.server.cve:ste:14{data[patch]}04"/>
</xmlfilecontent_test>
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:tst:814{data[ver_id]}{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Linux (Standalone) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)" deprecated="false">
  <object object_ref="oval:org.tanium.unix.oracle.database.server.cve:obj:81400{data[ver_id]}00"/>
  <state state_ref="oval:org.tanium.unix.oracle.database.server.cve:ste:14{data[patch]}04"/>
</xmlfilecontent_test>
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:tst:914{data[ver_id]}{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Linux (EM) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)" deprecated="false">
  <object object_ref="oval:org.tanium.unix.oracle.database.server.cve:obj:91400{data[ver_id]}00"/>
  <state state_ref="oval:org.tanium.unix.oracle.database.server.cve:ste:14{data[patch]}04"/>
</xmlfilecontent_test>'''

patch_test_tmp_l_ojvm='''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:tst:71401{data[ver_id]}{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Linux (Docker) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)" deprecated="false">
  <object object_ref="oval:org.tanium.unix.oracle.database.server.cve:obj:71401{data[ver_id]}00"/>
  <state state_ref="oval:org.tanium.unix.oracle.database.server.cve:ste:14{data[patch]}04"/>
</xmlfilecontent_test>
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:tst:81401{data[ver_id]}{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Linux (Standalone) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)" deprecated="false">
  <object object_ref="oval:org.tanium.unix.oracle.database.server.cve:obj:81401{data[ver_id]}00"/>
  <state state_ref="oval:org.tanium.unix.oracle.database.server.cve:ste:14{data[patch]}04"/>
</xmlfilecontent_test>
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:tst:91401{data[ver_id]}{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Linux (EM) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)" deprecated="false">
  <object object_ref="oval:org.tanium.unix.oracle.database.server.cve:obj:91401{data[ver_id]}00"/>
  <state state_ref="oval:org.tanium.unix.oracle.database.server.cve:ste:14{data[patch]}04"/>
</xmlfilecontent_test>'''


patch_object_tmp_l = '''
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:obj:81400{data[ver_id]}00" version="1" comment="Object collects Oracle Database Server version {data[ver]} for Linux (Standalone)" deprecated="false">
  <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.unix.oracle.database.server.cve:var:10021" var_check="at least one"/>
  <xpath datatype="string" operation="equals" mask="false">//patch_description[(contains(text(),'Database') or contains(text(),'DATABASE')) and contains(text()," {data[ver_pat]}")]//following-sibling::patch_id/@number</xpath>
  <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.database.server.cve:ste:1000</filter>
</xmlfilecontent_object>
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:obj:71400{data[ver_id]}00" version="1" comment="Object collects Oracle Database Server version {data[ver]} for Linux (Docker)" deprecated="false">
  <filepath datatype="string" operation="pattern match" mask="false">^/u01/app/oracle/product/.*/dbhome_1/\.patch_storage/\w+/original_patch/etc/config/inventory\.xml$</filepath>
  <xpath datatype="string" operation="equals" mask="false">//patch_description[(contains(text(),'Database') or contains(text(),'DATABASE')) and contains(text()," {data[ver_pat]}")]//following-sibling::patch_id/@number</xpath>
  <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.database.server.cve:ste:1000</filter>
</xmlfilecontent_object>
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:obj:91400{data[ver_id]}00" version="1" comment="Object collects Oracle Database Server version {data[ver]} for Linux (EM)" deprecated="false">
  <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.unix.oracle.database.server.cve:var:20031" var_check="at least one"/>
  <xpath datatype="string" operation="equals" mask="false">//patch_description[(contains(text(),'Database') or contains(text(),'DATABASE')) and contains(text()," {data[ver_pat]}")]//following-sibling::patch_id/@number</xpath>
  <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.database.server.cve:ste:1000</filter>
</xmlfilecontent_object>'''

patch_object_tmp_l_ojvm = '''
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:obj:81401{data[ver_id]}00" version="1" comment="Object collects Oracle Database Server version {data[ver]} for Linux (Standalone)" deprecated="false">
  <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.unix.oracle.database.server.cve:var:10021" var_check="at least one"/>
  <xpath datatype="string" operation="equals" mask="false">//patch_description[contains(text(),'OJVM') and contains(text()," {data[ver_pat]}")]//following-sibling::patch_id/@number</xpath>
  <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.database.server.cve:ste:1000</filter>
</xmlfilecontent_object>
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:obj:71401{data[ver_id]}00" version="1" comment="Object collects Oracle Database Server version {data[ver]} for Linux (Docker)" deprecated="false">
  <filepath datatype="string" operation="pattern match" mask="false">^/u01/app/oracle/product/.*/dbhome_1/\.patch_storage/\w+/original_patch/etc/config/inventory\.xml$</filepath>
  <xpath datatype="string" operation="equals" mask="false">//patch_description[contains(text(),'OJVM') and contains(text()," {data[ver_pat]}")]//following-sibling::patch_id/@number</xpath>
  <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.database.server.cve:ste:1000</filter>
</xmlfilecontent_object>
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:obj:91401{data[ver_id]}00" version="1" comment="Object collects Oracle Database Server version {data[ver]} for Linux (EM)" deprecated="false">
  <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.unix.oracle.database.server.cve:var:20031" var_check="at least one"/>
  <xpath datatype="string" operation="equals" mask="false">//patch_description[contains(text(),'OJVM') and contains(text()," {data[ver_pat]}")]//following-sibling::patch_id/@number</xpath>
  <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.database.server.cve:ste:1000</filter>
</xmlfilecontent_object>'''

version_state_tmp_l='''
<textfilecontent54_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:ste:11{data[ver_id]}05" version="1" operator="AND" comment="State for Oracle Database Server is matches for {data[ver]}" deprecated="false">
  <subexpression entity_check="all" check_existence="at_least_one_exists" datatype="string" operation="pattern match" mask="false">^{data[ver_pat]}</subexpression>
</textfilecontent54_state>'''

patch_state_tmp_l='''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.database.server.cve:ste:14{data[patch]}04" version="1" operator="AND" comment="State for Oracle Database Server is matches greater than or equal to {data[patch]} (Patch ID)" deprecated="false">
 <value_of entity_check="at least one" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[patch]}</value_of>
</xmlfilecontent_state>'''

version_patch_criterion_s_l='''
<criteria operator="AND" negate="false" comment="version for {data[ver]}">
<criterion test_ref="oval:org.tanium.unix.oracle.database.server.cve:tst:811{data[ver_id]}05" negate="false" comment="Check for Oracle Database Server for Linux (Standalone) version are {data[ver]}"/>
<criterion test_ref="oval:org.tanium.unix.oracle.database.server.cve:tst:814{data[ver_id]}{data[patch]}04" negate="true" comment="Check for Oracle Database Server for Linux (Standalone) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)"/>
</criteria>'''
version_patch_criterion_d_l='''
<criteria operator="AND" negate="false" comment="version for {data[ver]}">
<criterion test_ref="oval:org.tanium.unix.oracle.database.server.cve:tst:711{data[ver_id]}05" negate="false" comment="Check for Oracle Database Server for Linux (Docker) version are {data[ver]}"/>
<criterion test_ref="oval:org.tanium.unix.oracle.database.server.cve:tst:714{data[ver_id]}{data[patch]}04" negate="true" comment="Check for Oracle Database Server for Linux (Docker) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)"/>
</criteria>'''
version_patch_criterion_em_l='''
<criteria operator="AND" negate="false" comment="version for {data[ver]}">
<criterion test_ref="oval:org.tanium.unix.oracle.database.server.cve:tst:911{data[ver_id]}05" negate="false" comment="Check for Oracle Database Server for Linux (EM) version are {data[ver]}"/>
<criterion test_ref="oval:org.tanium.unix.oracle.database.server.cve:tst:914{data[ver_id]}{data[patch]}04" negate="true" comment="Check for Oracle Database Server for Linux (EM) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)"/>
</criteria>'''

version_patch_criterion_s_v_l='''
<criterion test_ref="oval:org.tanium.unix.oracle.database.server.cve:tst:811{data[ver_id]}05" negate="false" comment="Check for Oracle Database Server for Linux (Standalone) version are {data[ver]}"/>
'''
version_patch_criterion_d_v_l='''
<criterion test_ref="oval:org.tanium.unix.oracle.database.server.cve:tst:711{data[ver_id]}05" negate="false" comment="Check for Oracle Database Server for Linux (Docker) version are {data[ver]}"/>
'''
version_patch_criterion_em_v_l='''
<criterion test_ref="oval:org.tanium.unix.oracle.database.server.cve:tst:911{data[ver_id]}05" negate="false" comment="Check for Oracle Database Server for Linux (EM) version are {data[ver]}"/>
'''
### Windows ###

ver_test_tmp_w='''
<textfilecontent54_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.database.server.cve:tst:811{data[ver_id]}05" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Windows (Standalone) version are {data[ver]}" deprecated="false">
  <object object_ref="oval:org.tanium.windows.oracle.database.server.cve:obj:1002"/>
  <state state_ref="oval:org.tanium.windows.oracle.database.server.cve:ste:11{data[ver_id]}05"/>
</textfilecontent54_test>
<textfilecontent54_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.database.server.cve:tst:911{data[ver_id]}05" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Windows (EM) version are {data[ver]}" deprecated="false">
  <object object_ref="oval:org.tanium.windows.oracle.database.server.cve:obj:2002"/>
  <state state_ref="oval:org.tanium.windows.oracle.database.server.cve:ste:11{data[ver_id]}05"/>
</textfilecontent54_test>'''

patch_test_tmp_w='''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.database.server.cve:tst:814{data[ver_id]}{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Windows (Standalone) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)" deprecated="false">
  <object object_ref="oval:org.tanium.windows.oracle.database.server.cve:obj:81400{data[ver_id]}00"/>
  <state state_ref="oval:org.tanium.windows.oracle.database.server.cve:ste:14{data[patch]}04"/>
</xmlfilecontent_test>
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.database.server.cve:tst:914{data[ver_id]}{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle Database Server for Windows (EM) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)" deprecated="false">
  <object object_ref="oval:org.tanium.windows.oracle.database.server.cve:obj:91400{data[ver_id]}00"/>
  <state state_ref="oval:org.tanium.windows.oracle.database.server.cve:ste:14{data[patch]}04"/>
</xmlfilecontent_test>'''


patch_object_tmp_w = '''
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.database.server.cve:obj:81400{data[ver_id]}00" version="1" comment="Object collects Oracle Database Server version {data[ver]} for Windows (Standalone)" deprecated="false">
  <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.windows.oracle.database.server.cve:var:10011" var_check="at least one"/>
  <xpath datatype="string" operation="equals" mask="false">//patch_description[(contains(text(),'Database') or contains(text(),'DATABASE')) and contains(text()," {data[ver_pat]}")]//following-sibling::patch_id/@number</xpath>
  <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.windows.oracle.database.server.cve:ste:1000</filter>
</xmlfilecontent_object>
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.database.server.cve:obj:91400{data[ver_id]}00" version="1" comment="Object collects Oracle Database Server version {data[ver]} for Windows (EM)" deprecated="false">
  <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.windows.oracle.database.server.cve:var:20011" var_check="at least one"/>
  <xpath datatype="string" operation="equals" mask="false">//patch_description[(contains(text(),'Database') or contains(text(),'DATABASE')) and contains(text()," {data[ver_pat]}")]//following-sibling::patch_id/@number</xpath>
  <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.windows.oracle.database.server.cve:ste:1000</filter>
</xmlfilecontent_object>'''

version_state_tmp_w='''
<textfilecontent54_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.database.server.cve:ste:11{data[ver_id]}05" version="1" operator="AND" comment="State for Oracle Database Server is matches for {data[ver]}" deprecated="false">
  <subexpression entity_check="all" check_existence="at_least_one_exists" datatype="string" operation="pattern match" mask="false">^{data[ver_pat]}</subexpression>
</textfilecontent54_state>'''

patch_state_tmp_w='''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.database.server.cve:ste:14{data[patch]}04" version="1" operator="AND" comment="State for Oracle Database Server is matches greater than or equal to {data[patch]} (Patch ID)" deprecated="false">
 <value_of entity_check="at least one" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[patch]}</value_of>
</xmlfilecontent_state>'''

version_patch_criterion_s_w='''
<criteria operator="AND" negate="false" comment="version for {data[ver]}">
<criterion test_ref="oval:org.tanium.windows.oracle.database.server.cve:tst:811{data[ver_id]}05" negate="false" comment="Check for Oracle Database Server for Windows (Standalone) version are {data[ver]}"/>
<criterion test_ref="oval:org.tanium.windows.oracle.database.server.cve:tst:814{data[ver_id]}{data[patch]}04" negate="true" comment="Check for Oracle Database Server for Windows (Standalone) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)"/>
</criteria>'''
version_patch_criterion_em_w='''
<criteria operator="AND" negate="false" comment="version for {data[ver]}">
<criterion test_ref="oval:org.tanium.windows.oracle.database.server.cve:tst:911{data[ver_id]}05" negate="false" comment="Check for Oracle Database Server for Windows (EM) version are {data[ver]}"/>
<criterion test_ref="oval:org.tanium.windows.oracle.database.server.cve:tst:914{data[ver_id]}{data[patch]}04" negate="true" comment="Check for Oracle Database Server for Windows (EM) version {data[ver]} patch is greater than or equal to {data[patch]} (Patch ID)"/>
</criteria>'''

version_patch_criterion_s_v_w='''
<criterion test_ref="oval:org.tanium.windows.oracle.database.server.cve:tst:811{data[ver_id]}05" negate="false" comment="Check for Oracle Database Server for Windows (Standalone) version are {data[ver]}"/>
'''
version_patch_criterion_em_v_w='''
<criterion test_ref="oval:org.tanium.windows.oracle.database.server.cve:tst:911{data[ver_id]}05" negate="false" comment="Check for Oracle Database Server for Windows (EM) version are {data[ver]}"/>'''

class ChangeTemplateLinux():
    def __init__(self, cve_file: str):
        version_tests = ''
        patch_tests = ''
        patch_objects = ''
        patch_states = ''
        version_states = ''
        criterion_standalone = ''
        criterion_docker = ''
        criterion_em = ''
        fs = open(cve_file, 'r')
        content = fs.read().encode('utf-8')
        fs.close()
        raw = lhtml.fromstring(content)
        cve = raw.xpath('//reference[@source="CVE"]/@ref_id')[0]
        desc = raw.xpath('//definition[@class="vulnerability"]//description/text()')[0]
        print(f"Generating {cve} ... ")
        version_json_cve = pd.read_csv('/home/sujan/Docuents/work/OracleDatabase.csv')
        versions = [pat.replace('\.', '.').replace('^','').strip() for pat in raw.xpath('//subexpression/text()') if '$' not in pat]
        for ver in versions:
            try:
              patch = version_json_cve[version_json_cve.CVE == f"{cve}"].get(ver)
            except Exception:
               continue
            data = {
                'ver': ver,
                'ver_id': "".join([f'{_ver:0>2}' for _ver in ver.split('.')]),
                'patch': patch,
                'ver_pat': ver.replace('.', '\.')
            }
            if patch == "NE":
              criterion_standalone += version_patch_criterion_s_v_l.format(data=data)
              criterion_docker += version_patch_criterion_d_v_l.format(data=data)
              criterion_em += version_patch_criterion_em_v_l.format(data=data)
              version_tests += ver_test_tmp_l.format(data=data)
              version_states += version_state_tmp_l.format(data=data)
              continue
            criterion_standalone += version_patch_criterion_s_l.format(data=data)
            criterion_docker += version_patch_criterion_d_l.format(data=data)
            criterion_em += version_patch_criterion_em_l.format(data=data)
            version_tests += ver_test_tmp_l.format(data=data)
            version_states += version_state_tmp_l.format(data=data)
            patch_tests += patch_test_tmp_l.format(data=data)
            if "OJVM" in desc:
               patch_objects += patch_object_tmp_l_ojvm.format(data=data)
            else:
              patch_objects += patch_object_tmp_l.format(data=data)
            if str(patch) not in patch_states:
              patch_states += patch_state_tmp_l.format(data=data)

        fs_r = open('/home/sujan/OVAL/src/tmp/template-lin-oracle-db.xml', 'r')
        content_r_tmp = fs_r.read()
        fs_r.close()
        data = {
            'criterion_standalone': criterion_standalone,
            'criterion_docker': criterion_docker,
            'criterion_em': criterion_em,
            'version_tests': version_tests,
            'version_states': version_states,
            'patch_tests': patch_tests,
            'patch_objects': patch_objects,
            'patch_states': patch_states,
            'cve': cve,
            'cve_raw': "".join(cve.split('-')[1::]),
            'title': raw.xpath('//definition[@class="vulnerability"]//title/text()')[0],
            'desc': raw.xpath('//definition[@class="vulnerability"]//description/text()')[0],
            'adid': raw.xpath('//definition[@class="vulnerability"]//reference[@source="VENDOR"]/@ref_id')[0],
            'adurl': raw.xpath('//definition[@class="vulnerability"]//reference[@source="VENDOR"]/@ref_url')[0]
        }
        content = content_r_tmp.format(data=data)
        fs_w = open(f"{cve}-lin-oracle-db.xml", "w")
        fs_w.write(content)
        fs_w.close()


class ChangeTemplateWindows():
    def __init__(self, cve_file: str):
        version_tests = ''
        patch_tests = ''
        patch_objects = ''
        patch_states = ''
        version_states = ''
        criterion_standalone = ''
        criterion_docker = ''
        criterion_em = ''
        fs = open(cve_file, 'r')
        content = fs.read().encode('utf-8')
        fs.close()
        raw = lhtml.fromstring(content)
        cve = raw.xpath('//reference[@source="CVE"]/@ref_id')[0]
        print(f"Generating {cve} ... ")
        version_json_cve = pd.read_csv('/home/sujan/Documents/work/OracleDatabase.csv')
        versions = [pat.replace('\.', '.').replace('^','').strip() for pat in raw.xpath('//subexpression/text()') if '$' not in pat]
        for ver in versions:
            try:
              patch = version_json_cve[version_json_cve.CVE == f"{cve}"].get(ver).item()
              if ',' in patch:
                patch = patch.split(',')[1].strip()
            except Exception:
               continue
            data = {
                'ver': ver,
                'ver_id': "".join([f'{_ver:0>2}' for _ver in ver.split('.')]),
                'patch': patch,
                'ver_pat': ver.replace('.', '\.')
            }
            if patch == "NE":
              criterion_standalone += version_patch_criterion_s_v_w.format(data=data)
              criterion_em += version_patch_criterion_em_v_w.format(data=data)
              version_tests += ver_test_tmp_w.format(data=data)
              version_states += version_state_tmp_w.format(data=data)
              continue
            criterion_standalone += version_patch_criterion_s_w.format(data=data)
            criterion_em += version_patch_criterion_em_w.format(data=data)
            version_tests += ver_test_tmp_w.format(data=data)
            version_states += version_state_tmp_w.format(data=data)
            patch_tests += patch_test_tmp_w.format(data=data)
            patch_objects += patch_object_tmp_w.format(data=data)
            if str(patch) not in patch_states:
              patch_states += patch_state_tmp_w.format(data=data)

        fs_r = open('/home/sujan/OVAL/src/tmp/template-win-oracle-db.xml', 'r')
        content_r_tmp = fs_r.read()
        fs_r.close()
        data = {
            'criterion_standalone': criterion_standalone,
            'criterion_docker': criterion_docker,
            'criterion_em': criterion_em,
            'version_tests': version_tests,
            'version_states': version_states,
            'patch_tests': patch_tests,
            'patch_objects': patch_objects,
            'patch_states': patch_states,
            'cve': cve,
            'cve_raw': "".join(cve.split('-')[1::]),
            'title': raw.xpath('//definition[@class="vulnerability"]//title/text()')[0],
            'desc': raw.xpath('//definition[@class="vulnerability"]//description/text()')[0],
            'adid': raw.xpath('//definition[@class="vulnerability"]//reference[@source="VENDOR"]/@ref_id')[0],
            'adurl': raw.xpath('//definition[@class="vulnerability"]//reference[@source="VENDOR"]/@ref_url')[0]
        }
        content = content_r_tmp.format(data=data)
        fs_w = open(f"{cve}-win-oracle-db.xml", "w")
        fs_w.write(content)
        fs_w.close()
        
ChangeTemplateWindows(sys.argv[1])