## Oracle Notes on Advisory

 + CVRF
   - https://www.oracle.com/docs/tech/security-alerts/1932662.xml
   - Availability: from jul 2012
CVE-2012-3134
 + CSAF

https://www.oracle.com/security-alerts/
https://www.oracle.com/security-alerts/cpufaq.html#CVRF
https://www.oracle.com/docs/tech/security-alerts/oracle-cpu-csaf-rss.xml
https://www.oracle.com/security-alerts/public-vuln-to-advisory-mapping.html
 + Text Form of Oracle Critical Patch Update
   - https://www.oracle.com/security-alerts/cpujul2012verbose.html
