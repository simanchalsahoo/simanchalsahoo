import cveprey
import lxml.html as lhtml

adv_patch = cveprey.oraclePatches()
adv_patch._init_patch_session("skokkanthi@loginsoft.com", "OS@login123")
cve_file = open('/home/sujan/Documents/CVE/checking/db/to-check-patches-23-09-2023')
cves = "".join(cve_file.readlines()).split('\n')
cve_file.close()

for cve in cves:
    
    cve_file = open(f'/home/sujan/Downloads/oracle-db-win-256-code-review/sujan/{cve}-win-oracle-db.xml')
    contents = cve_file.read()
    cve_file.close()
    root = lhtml.fromstring(contents.encode('utf-8'))

    adv_link = root.xpath('//reference[@source="VENDOR"]/@ref_url')[0]
    adv = cveprey.oracleAdvisories([adv_link], cve)
    strings = "".join(adv_patch._getPatchstrings(cve, adv.patch_links['Database Server']))

    patches = root.xpath('//value_of[@operation="greater than or equal"]/text()')
    for patch in patches:
        if patch not in strings:
            print(f'{patch} not found in {cve}')
        else:
            print(f'{cve} is Fine !')