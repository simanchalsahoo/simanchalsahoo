import cveprey, time

username="skokkanthi@loginsoft.com"
password="OS@login123"

patch_driver = cveprey.oraclePatches(username, password)


oms_criteria_ver_patch='''<criteria operator="AND" comment="Check for OMS Version {data[ver]} from oragchomelist">
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:6001" negate="false" comment="Oracle Enterprise Manager Base Platform is installed oragchomelist path Linux (older versions) OMS"/>
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1489{data[ver_id]}00" negate="false" comment="Check for Oracle Enterprise Manager Base Platform version {data[ver]} (older version) OMS"/>
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1489{data[patch]}04" negate="true" comment="Check for Oracle Enterprise Manager Base Platform patch greater than or equal to {data[patch]} (older version) OMS"/>
          </criteria>
          <criteria operator="AND" negate="false" comment="Check for OMS Version {data[ver]} from oraInst.loc">
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1000" negate="false" comment="Check for oraInst"/>
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:7001" negate="false" comment="Oracle Enterprise Manager Base Platform is installed oraInst path Linux (newer versions) OMS"/>
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1478{data[ver_id]}00" negate="false" comment="Check for Oracle Enterprise Manager Base Platform version {data[ver]} (newer version) OMS"/>
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1478{data[patch]}04" negate="true" comment="Check for Oracle Enterprise Manager Base Platform patch greater than or equal to {data[patch]} (newer version) agent"/>
          </criteria>
'''

oms_criteria_ver='''<criteria operator="AND" comment="Check for OMS Version {data[ver]} from oragchomelist">
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:6001" negate="false" comment="Oracle Enterprise Manager Base Platform is installed oragchomelist path Linux (older versions) OMS"/>
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1489{data[ver_id]}00" negate="false" comment="Check for Oracle Enterprise Manager Base Platform version {data[ver]} (older version) OMS"/>
          </criteria>
          <criteria operator="AND" negate="false" comment="Check for OMS Version {data[ver]} from oraInst.loc">
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1000" negate="false" comment="Check for oraInst"/>
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:7001" negate="false" comment="Oracle Enterprise Manager Base Platform is installed oraInst path Linux (newer versions) OMS"/>
            <criterion test_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1478{data[ver_id]}00" negate="false" comment="Check for Oracle Enterprise Manager Base Platform version {data[ver]} (newer version) OMS"/>
          </criteria>
'''
oms_ver_test = '''<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1478{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="at least one" comment="Check for Oracle Enterprise Manager Base Platform version {data[ver]} (newer version) OMS" deprecated="false">
      <object object_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:obj:7003"/>
      <state state_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:ste:14{data[ver_id]}00"/>
    </xmlfilecontent_test>
    <xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1489{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="at least one" comment="Check for Oracle Enterprise Manager Base Platform version {data[ver]} (older version) OMS" deprecated="false">
      <object object_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:obj:6002"/>
      <state state_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:ste:14{data[ver_id]}00"/>
    </xmlfilecontent_test>
'''
oms_patch_test = '''<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1489{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" comment="Check for Oracle Enterprise Manager Base Platform patche greater than or equal to {data[patch]} (older version) OMS" deprecated="false">
      <object object_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:obj:1489{data[ver_id]}00"/>
      <state state_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:ste:14{data[patch]}04"/>
    </xmlfilecontent_test>
    <xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.enterprise.manager.cve:tst:1478{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" comment="Check for Oracle Enterprise Manager Base Platform patche greater than or equal to {data[patch]} (newer version) OMS" deprecated="false">
      <object object_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:obj:1478{data[ver_id]}00"/>
      <state state_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:ste:14{data[patch]}04"/>
    </xmlfilecontent_test>
'''
oms_patch_objects='''<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.enterprise.manager.cve:obj:1478{data[ver_id]}00" version="1" comment="Object that collects installed patch version for OMS (newer version)" deprecated="false">
      <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:var:3003" var_check="at least one"/>
      <xpath datatype="string" operation="equals" mask="false">//*[//components[@internal_name="oracle.sysman.top.oms" and @version="{data[ver]}"] and (name()="patch_id" or name()="reference_id")]/@number</xpath>
      <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.enterprise.manager.cve:ste:1000</filter>
    </xmlfilecontent_object>
    <xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.enterprise.manager.cve:obj:1489{data[ver_id]}00" version="1" comment="Object that collects installed patch version for OMS (older version)" deprecated="false">
      <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.unix.oracle.enterprise.manager.cve:var:2003" var_check="at least one"/>
      <xpath datatype="string" operation="equals" mask="false">//*[//components[@internal_name="oracle.sysman.top.oms" and @version="{data[ver]}"] and (name()="patch_id" or name()="reference_id")]/@number</xpath>
      <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.enterprise.manager.cve:ste:1000</filter>
    </xmlfilecontent_object>
'''

ver_state='''<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.enterprise.manager.cve:ste:14{data[ver_id]}00" version="1" operator="AND" comment="State for Oracle Enterprise Manager Base Platform  is equals {data[ver]}" deprecated="false">
      <value_of entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="equals" mask="false">{data[ver]}</value_of>
    </xmlfilecontent_state>
'''
patch_state='''<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.enterprise.manager.cve:ste:14{data[patch]}04" version="1" operator="AND" comment="State for Oracle Enterprise Manager Base Platform OMS patch is greater than or equal {data[patch]}" deprecated="false">
      <value_of entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[patch]}</value_of>
    </xmlfilecontent_state>'''


class loadPatches(object):
    def __init__(self, frame):
        patch_set = {}
        tmp_ = open('/home/sujan/OVAL/src/tmp/lin-oracle-embp-oms.xml.tmp', 'r')
        tmp_src = tmp_.read()
        tmp_.close()
        oms_pat_tests=''
        oms_ver_tests=''
        oms_crit_ver=''
        oms_cri_pat_ver=''
        oms_pat_obj=''
        ver_ste=''
        pat_ste=''
        _ = frame.split(',')
        print(_)
        cve = _[0]
        patch_set[cve] = {}
        cve_info = cveprey.CVE(cve)
        cve_info.get_nvd_data()
        adv = cveprey.oracleAdvisories([_[1]],_[0])
        patch_link = list(set(adv.root.xpath('.//td/a[@target="_blank" and ./text()="Enterprise Manager"]/@href')))[0]
        print(patch_link)
        try:
            key_pat = [i for i in adv.versions.keys() if "Oracle Enterprise Manager" in i]
            versions = []
            for v_k in key_pat:
                versions.extend(adv.versions[v_k])
            tmp_cve = cve
        except Exception:
            elem = adv.root.xpath('//*[contains(./text(), "patch for") and contains(./text(), "addresses")]/text()')[0]
            c = cveprey.re.findall(r"(CVE-\d+-\d+)", elem)[0]
            tmp_cve = c
        
        string = patch_driver.getPatches(tmp_cve, patch_link)
        versions_ext = cveprey.re.findall(r"\(([\d\.]+)\)", "".join(string))
        versions.extend(versions_ext)
        versions = list(set(versions))
        for ver in versions:
            patch_set[cve][ver] = {}

            ver_match = ver
            if len(ver.split('.'))>4 and (ver.split('.')[-1] == '0'):
                ver_match = ver[:-1]

            match = [cveprey.re.findall(r"[Pp]atch\s+(\d+)", string)[0]
                    for _string in string 
                    if ("Base Platform" in _string) 
                    and ver_match in _string
                    and len(cveprey.re.findall(r"[Pp]atch\s+(\d+)", _string)) > 0
                    ]

            if len(match)>0:
                patch_set[cve][ver]["OMS"] = match[0]
            else:
                patch_set[cve][ver]["OMS"] = ''

            data = {
                'ver': ver,
                'ver_id': "".join([f'{v:0>2}' for v in ver.split('.')]),
                'patch': patch_set[cve][ver]["OMS"],
            }

            if ver not in ver_ste:
                oms_ver_tests += oms_ver_test.format(data=data)
                ver_ste += ver_state.format(data=data)

            print(data)
            if patch_set[cve][ver]["OMS"] == '':
                oms_crit_ver += oms_criteria_ver.format(data=data)
                continue
            oms_cri_pat_ver += oms_criteria_ver_patch.format(data=data)
            oms_pat_tests += oms_patch_test.format(data=data)
            oms_pat_obj += oms_patch_objects.format(data=data)
            pat_ste += patch_state.format(data=data)

        data = {
            'cve': cve,
            'title': "",
            'cve_raw': "".join(cve.split('-')[1::]),
            'desc': cve_info.nvd_data.description,
            'adurl': _[1],
            'adid': cveprey.re.findall(r'/(cpu.*).html', _[1])[0].upper(),
            'ver_tests': oms_ver_tests,
            'patch_tests': oms_pat_tests,
            'patch_objects': oms_pat_obj,
            'criteria': oms_crit_ver+oms_cri_pat_ver,
            'ver_state': ver_ste,
            'patch_states': pat_ste

        }
        content_src = tmp_src.format(data=data)
        fp = open(f"{cve}-lin-oracle-embp.xml", "w")
        fp.write(content_src)
        print(f"Done -- {cve}")
        fp.close()

try:
    frame = open("/home/sujan/Documents/CVE/EM/cves1.txt").read()
    frame = frame.split('\n')
    for cve in frame:
        loadPatches(cve)
except Exception as err:
    print(err)
    patch_driver.quit()