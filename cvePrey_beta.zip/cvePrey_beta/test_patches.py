import cveprey

patch_driver = cveprey.oraclePatches()
patch_driver._init_patch_session(username="skokkanthi@loginsoft.com", password="OS@login123")

adv = cveprey.oracleAdvisories(["https://www.oracle.com/security-alerts/cpujul2022.html"], "CVE-2020-35169")
print(adv.versions)
print(adv.patch_links)

for k, v in adv.patch_links.items():
    if v != '':
        patch_strings = patch_driver._getPatchstrings("CVE-2020-35169", v)
        print(patch_strings)
    else:
        continue