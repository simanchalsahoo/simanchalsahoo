import cveprey, re

crit_OR = '''
<criteria operator="OR" comment="Check for affected Versions and patches">
	{data[versions_criterion]}
	{data[pat_criterion]}
</criteria>
'''
new_ver_pat_criteria = '''
<criteria operator="AND" comment="Check for Oracle WebCenter Content {data[version]} and {data[pat]}">
	<criterion test_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:tst:814{data[version_raw]}05" negate="false" comment="Check for Oracle WebCenter Content for windows newer version is equal to {data[version]}"/>
	<criteria operator="AND" negate="true" comment="Checking for Oracle WebCenter Content {data[pat]} patch">
	  <criterion test_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:tst:814{data[pat]}04" negate="false" comment="Check for Oracle WebCenter Content patch greater than or equal to {data[pat]}"/>
	  <criterion test_ref="oval:org.tanium.windows.oracle.cve:tst:1002" negate="false" comment="Check for .patch_storage dir existence"/>
	</criteria>
</criteria>'''

old_ver_pat_criteria = '''
<criteria operator="AND" comment="Check for Oracle WebCenter Content {data[version]} and {data[pat]}">
	<criterion test_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:tst:914{data[version_raw]}05" negate="false" comment="Check for Oracle WebCenter Content for windows older version is equal to {data[version]}"/>
	<criterion test_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:tst:914{data[pat]}04" negate="true" comment="Check for Oracle WebCenter Content patch greater than or equal to {data[pat]}"/>
</criteria>'''

new_single_ver = '''
<criterion test_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:tst:814{data[version_raw]}05" negate="false" comment="Check for Oracle WebCenter Contentfor windows newer version equals to {data[version]}"/>\n
'''

old_single_ver = '''
<criterion test_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:tst:914{data[version_raw]}05" negate="false" comment="Check for Oracle WebCenter Contentfor windows older version equals to {data[version]}"/>\n
'''

ver_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.webcenter.content.cve:tst:{data[dynamic_tstid]}" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle WebCenter Contentfor windows version equals to {data[version]}" deprecated="false">
	<object object_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:obj:{data[dynamic_objid]}"/>
	<state state_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:ste:14{data[version_raw]}05"/>
</xmlfilecontent_test>\n
'''

new_pat_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.webcenter.content.cve:tst:814{data[pat]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for windows newer version {data[version]} Patches greater than or equal to {data[pat]}" deprecated="false">
	<object object_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:obj:814{data[version_raw]}00"/>
	<state state_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:ste:14{data[pat]}04"/>
</xmlfilecontent_test>\n'''

old_pat_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.webcenter.content.cve:tst:914{data[pat]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for windows older version {data[version]} Patches greater than or equal to {data[pat]}" deprecated="false">
	<object object_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:obj:914{data[version_raw]}00"/>
	<state state_ref="oval:org.tanium.windows.oracle.webcenter.content.cve:ste:14{data[pat]}04"/>
</xmlfilecontent_test>\n'''

new_pat_object = '''
 <xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.webcenter.content.cve:obj:814{data[version_raw]}00" version="1" comment="Object that collects installed patch for newer version " deprecated="false">
	  <filepath datatype="string" operation="equals" mask="false" var_ref="oval:org.tanium.windows.oracle.cve:var:1002" var_check="at least one"/>
      <xpath datatype="string" operation="equals" mask="false">//*[//component[contains(@internal_name, "oracle.webcenter.content") and @version="{data[version]}"] and (name()="patch_id" or name()="reference_id")]/@number</xpath>
	  <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.windows.oracle.cve:ste:1000</filter>
</xmlfilecontent_object>\n'''

old_pat_object = '''
 <xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.webcenter.content.cve:obj:914{data[version_raw]}00" version="1" comment="Object that collects installed patch for older version is {data[version]} " deprecated="false">
	  <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.windows.oracle.cve:var:1004" var_check="at least one"/>
      <xpath datatype="string" operation="equals" mask="false">//*[//component[contains(@internal_name, "oracle.contentserver11") and @version="{data[version]}"] and (name()="patch_id" or name()="reference_id")]/@number</xpath>
	  <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.windows.oracle.cve:ste:1000</filter>
</xmlfilecontent_object>\n'''

ver_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.webcenter.content.cve:ste:14{data[version_raw]}05" version="1" operator="AND" comment="State for Oracle WebCenter Contentis {data[version]}" deprecated="false">
	<value_of entity_check="all" check_existence="at_least_one_exists" datatype="string" operation="pattern match" mask="false">^{data[version_pat]}.*$</value_of>
</xmlfilecontent_state>\n'''

pat_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.webcenter.content.cve:ste:14{data[pat]}04" version="1" operator="AND" comment="State for Oracle WebCenter Content patch is greater than or equal to {data[pat]} patches" deprecated="false">
	<value_of entity_check="at least one" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[pat]}</value_of>
</xmlfilecontent_state>\n'''


patch_driver = cveprey.oraclePatches()
patch_driver._init_patch_session("skokkanthi@loginsoft.com", "OS@login123")

class Webcenter():
	r'''
	Oracle WebCenter Content
	'''
	def __init__(self, cve:str):
		print(cve)
		self.cve = cve
		self.criteria = ""
		self.tests = ""
		self.pat_tests = ""
		self.pat_objects = ""
		self.states = ""
		self.pat_states = ""
		cve_info = cveprey.CVE(cve)
		cve_info.get_nvd_data()
		self.desc = cve_info.nvd_data.description
		try:
			self.title = re.findall(r"(\w+\s\w+\s\w+\s\(component\:[^\d]+\))", self.desc)[0]
		except IndexError:
			self.title = ""
		
		try:
			links = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link]
			if len(links) > 1:
				print("[!] Multiple Advisory Links Found")
				for number, link in zip(range(1, len(links)), links):
					print(f"{number} : {link}")
				t = int(input("Give Index Link of adv to use : "))
				links = [links[t-1]]
			else:
				links = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link]

		except IndexError:
			links = [input("Provide Adv Link : ")]
		adv = cveprey.oracleAdvisories(links, cve=cve, comp="Oracle WebCenter Content")
		# print ("Adv : ", adv, "\n", links)

		for link, prod in adv.adv_links.items():
			if "Oracle WebCenter Content" in "".join(prod):
				self.adv_link = link
		if len(adv.versions.keys()) < 1:
			if adv.addressed:
				tmp_cve = adv.addressed_cve
				adv = cveprey.oracleAdvisories(links, cve=tmp_cve)
		print("adv.versions: ", adv.versions)
		print(adv.adv_links)
		self.adv_link = "".join([key for key in list(adv.adv_links.keys()) if "Oracle WebCenter Content" in adv.adv_links[key]])
		# print("adv.patch_links: ", adv.patch_links)
		# print(adv.patch_links['Oracle WebCenter Content'])
		tmp_cve = cve
		if adv.addressed:
			tmp_cve = adv.addressed_cve
		print(adv.patch_links)
		strings = patch_driver._getPatchstrings(tmp_cve, adv.patch_links['Oracle WebCenter Content'])
		if len(strings) == 0:
			patch_string = list()
			content = patch_driver.driver.get(adv.patch_links['Oracle WebCenter Content'][0])
			contents = patch_driver.driver.page_source
			#print (contents)
			root = cveprey._core.lhtml.fromstring(contents)
			strings = root.xpath(f'//table[@rules="all"]//tr[.//*[contains(.//text(),"Oracle WebCenter Content")]]')
			patch_string.extend([" ".join(" ".join(i.xpath('.//text()')).split('\n')) for i in strings])
			if len(patch_string) == 0:
				strings = root.xpath(f'//table//tr[contains(.//text(),"Oracle WebCenter Content")]')
				patch_string.extend([" ".join(" ".join(i.xpath('.//text()')).split('\n')) for i in strings])
			strings = patch_string
		print (strings)


		print("Strings: ", strings)
		patch_numbers = re.findall(r'(?i)WCC\s+BP\s*(Bundle\s+Patch|BP|)\s*([\d\.]+)[\(\)\s]+Patch\s+(\d+)', " ".join(strings))
		# if len(patch_numbers) ==0:
		# 	patch_numbers = re.findall(r'(?i)(SOA\sBundle\sPatch)\s*([\w\.]+)\s*Patch\s*(\d+)', contents)
		# print("patch_numbers 1: ", patch_numbers)


#This is needed if 2 index value is coming
		'''if len(patch_numbers)<1:
			if not strings:
				print("No matching elements found.")
			else:
				patch_numbers = re.findall(r'(?i)WebCenter\s+\s+([\d\.]+)[\(\)\s]+Patch\s+(\d+)', "".join(strings))
				print("patch_numbers 2:", patch_numbers)'''



#This one needed when CVE need to search in Advisory page--------------------------------------------------
		'''if not 'oracle bi Webcenter' in strings:
			patch_numbers = re.findall(r'(?i)WebCenter\s+\s+([\d\.]+)[\(\)\s]+Patch\s+(\d+)', "".join(strings))
			print("patch_numbers 2: ", patch_numbers)
			'''
#--------------------------------------------------------------------------------------------------------
		try:
			# print("Versions 1: ", adv.versions)
			versions = list(map(lambda x: '.'.join(x.split('.')[:-1]) if len(x.split('.'))>4 else x, adv.versions['Oracle WebCenter Content']))
			self.writeCVE(versions, patch_numbers)
		except Exception:
			adid = re.findall(r"/(cpu[a-zA-Z0-9]+).*html", self.adv_link)[0].lower()
			_cvrf = cveprey.oracleCVRF()
			_adv = _cvrf._CVE(cve=cve, adid=adid)
			self.writeCVE(_cvrf.affected_version['WebCenter Content'])

	def writeCVE(self, versions:list=None, patches=list):
		patch_dic = {}
		_file_ = 'webcenter-content-Win-template.xml'

		tmp = open(_file_, 'r')
		content_read = tmp.read()
		tmp.close()
		tmp = open(f'{self.cve.upper()}-win-oracle-webcenter-content.xml', 'w')
		for version in sorted(versions):
			patch_dic[version] = {}
			# print(version, "==>", patches)
			for patch in patches:
				# print(f"Test patches : {patch[1]}")
				if version in patch[1]:
					patch_dic[version] = [patch[2]] if version in patch[1] else []
					if len(patch_dic[version])<1:
						patch_dic[version] = [patch[2] for patch in patches if patch[1].split('.')[:-1] == version.split('.')[:-2]]

		print("patch_numbers test: ", patch_dic)
		self.buildData(patch_dic)
		data = {
			'cve': self.cve,
			'cve_raw': "".join(self.cve.split('-')[1::]),
			'title': self.title,
			'adv_link': self.adv_link,
			'adid': re.findall(r"/(cpu.*).html", self.adv_link)[0].upper(),
			'adid_r': re.findall(r"/(cpu.*).html", self.adv_link)[0],
			'desc': self.desc,
			'criteria': self.criteria,
			'versions_tests': self.tests,
			'pat_tests': self.pat_tests,
			'version_states': self.states,
			'pat_objects': self.pat_objects,
			'pat_states': self.pat_states
		}
		content_read = content_read.format(data=data)
		tmp.write(content_read)
		tmp.close()

	def buildData(self, patch_dic):
		random = {"older": ["9", "1002"], "newer":  ["8" , "1001"]}
		for version in patch_dic.keys():
			version=".".join(version.split('.')[:-1]) if len(version.split('.'))>4 else version
			version_temp = ".".join(ver for ver in version.split('.')[:-1])
			version_raw = "".join([f'{ver:0>2}' for ver in version.split('.')])
			data_1 = {
				'version_raw': version_raw,
				'version': version,
				'version_pat': "\.".join(version.split(".")[:-1]) if len(version.split('.'))>4 else "\.".join(version.split(".")),
				'version_temp': version_temp
			}
			self.states += ver_state.format(data=data_1)

			#if version.startswith("5.") or version.startswith("6.") or version.startswith("7."):
				#data_1.update({"analytic_tstid": f"{random['analytic'][0]}14{version_raw}05", "analytic_objid": random["analytic"][1]})
				#self.tests += ana_ver_test.format(data=data_1)
				#if len(patch_dic[version])>0:
					#data_1.update({'pat': patch_dic[version][0]})
					#self.criteria += ana_ver_pat_criteria.format(data=data_1)
					#self.tests += ana_pat_test.format(data=data_1)
					#self.pat_objects += ana_pat_object.format(data=data_1)
					#self.states += pat_state.format(data=data_1)

				#random.pop('analytic')
				#continue

			for revision in random.keys():
				if revision == "older":
					data_1.update({"dynamic_tstid": f"{random['older'][0]}14{version_raw}05", "dynamic_objid": random["older"][1]})
					self.tests += ver_test.format(data=data_1)
					if len(patch_dic[version])>0:
						data_1.update({'pat': patch_dic[version][0]})
						self.criteria += old_ver_pat_criteria.format(data=data_1)
						self.tests += old_pat_test.format(data=data_1)
						self.pat_objects += old_pat_object.format(data=data_1)
						self.states += pat_state.format(data=data_1)

					else:
						self.criteria += old_single_ver.format(data=data_1)
				if revision == "newer":
					data_1.update({"dynamic_tstid": f"{random['newer'][0]}14{version_raw}05", "dynamic_objid": random["newer"][1]})
					self.tests += ver_test.format(data=data_1)
					if len(patch_dic[version])>0:
						data_1.update({'pat': patch_dic[version][0]})
						self.criteria += new_ver_pat_criteria.format(data=data_1)
						self.tests += new_pat_test.format(data=data_1)
						self.pat_objects += new_pat_object.format(data=data_1)
						# commented below line for unique patch state added above for older versions
						# self.states += pat_state.format(data=data_1)

					else:
						self.criteria += new_single_ver.format(data=data_1)

			
			

with open('examples.txt', 'r') as file:
	data = file.read().split()

for cve in data:
	Webcenter(cve)
patch_driver.driver.quit()
