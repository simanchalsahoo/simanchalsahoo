import cveprey, json, sys

fp = open(sys.argv[1], 'r')
contents = fp.read()
fp.close()

root = cveprey._core.lhtml.fromstring(contents.encode('utf-8'))
v_list = cveprey._core.re.findall(r'([\d\.A-Za-z]+) patches', contents)
year = cveprey._core.re.findall(r'cpu(.*)-?', root.xpath('.//reference[@source="VENDOR"]/@ref_id')[0])[0]
year = year.replace(year[0], year[0].upper())
year = year[:3] + '-' + "".join(cveprey._core.re.findall(r'([0-9]+)', year)[0])
#v_list = ['21', '19']
#year = "Apr-2023"
print(v_list, year)
adv = cveprey.oraclePatches(v_list, year)
print(adv.patches)
print(adv.date)
# tmp = json.dumps(adv.patches)
# tmp = json.loads(tmp)
#print(json.dumps(tmp, indent=4))
# for number in v_list:
#     text = number+' '+'patches'
#     # cmp = set(root.xpath(f'.//xmlfilecontent54_state[contains(@comment, "{text}")]/value_of[@datatype="version"]/text()'))
#     # if 'family="unix">' in contents:
#     l_ver = set(tmp[number]['linux'])
    # print(number + "==>" + str(l_ver.intersection(cmp)))
    # else:
    #     w_ver = set(tmp[number]['windows'])
    #     print(number + "==>" + str(w_ver.intersection(cmp)))
