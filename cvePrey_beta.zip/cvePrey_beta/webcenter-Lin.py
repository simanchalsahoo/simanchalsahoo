import cveprey, re

crit_OR = '''
<criteria operator="OR" comment="Check for affected Versions and patches">
    {data[versions_criterion]}
    {data[pat_criterion]}
</criteria>
'''
ver_pat_criteria = '''
<criteria operator="AND" comment="Check for Oracle WebCenter Portal {data[version]} and {data[pat]}">
    <criterion test_ref="oval:org.tanium.unix.oracle.webcenter.portal.cve:tst:14{data[version_raw]}05" negate="false" comment="Check for Oracle WebCenter Portal for Linux version is equal to {data[version]} (newer version)"/>
    <criteria operator="AND" negate="true" comment="Checking for Oracle WebCenter Portal {data[pat]} patch">
      <criterion test_ref="oval:org.tanium.unix.oracle.webcenter.portal.cve:tst:14{data[pat]}04" negate="false" comment="Check for Oracle WebCenter Portal patch greater than or equal to {data[pat]} (newer version)"/>
      <criterion test_ref="oval:org.tanium.unix.oracle.cve:tst:1003" negate="false" comment="Check for .patch_storage dir existence (newer version)"/>
    </criteria>
</criteria>'''

single_ver = '''
<criterion test_ref="oval:org.tanium.unix.oracle.webcenter.portal.cve:tst:14{data[version_raw]}05" negate="false" comment="Check for Oracle WebCenter Portal for Linux version equals to {data[version]}"/>\n
'''

ver_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.webcenter.portal.cve:tst:14{data[version_raw]}05" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for WebCenter Portal for Linux version equals to {data[version]}" deprecated="false">
    <object object_ref="oval:org.tanium.unix.oracle.webcenter.portal.cve:obj:1002"/>
    <state state_ref="oval:org.tanium.unix.oracle.webcenter.portal.cve:ste:14{data[version_raw]}05"/>
</xmlfilecontent_test>\n
'''

pat_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.webcenter.portal.cve:tst:14{data[pat]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Linux version {data[version]} Patches greater than or equal to {data[pat]}" deprecated="false">
    <object object_ref="oval:org.tanium.unix.oracle.webcenter.portal.cve:obj:14{data[version_raw]}00"/>
    <state state_ref="oval:org.tanium.unix.oracle.webcenter.portal.cve:ste:14{data[pat]}04"/>
</xmlfilecontent_test>\n'''

pat_object = '''
 <xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.webcenter.portal.cve:obj:14{data[version_raw]}00" version="1" comment="Object that collects installed patch version (newer versions)" deprecated="false">
      <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.unix.oracle.webcenter.portal.cve:var:1003" var_check="at least one"/>
      <xpath datatype="string" operation="equals" mask="false">//*[//component[contains(@internal_name, "oracle.webcenter.portal") and @version="{data[version]}"] and (name()="patch_id" or name()="reference_id")]/@number</xpath>
      <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.unix.oracle.webcenter.portal.cve:ste:1000</filter>
</xmlfilecontent_object>\n'''
 
ver_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.webcenter.portal.cve:ste:14{data[version_raw]}05" version="1" operator="AND" comment="State for WebCenter Portal is {data[version]}" deprecated="false">
    <value_of entity_check="all" check_existence="at_least_one_exists" datatype="string" operation="pattern match" mask="false">^{data[version_pat]}.*$</value_of>
</xmlfilecontent_state>\n'''

pat_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.webcenter.portal.cve:ste:14{data[pat]}04" version="1" operator="AND" comment="State for WebCenter Portal patch is greater than or equal to {data[pat]} patches" deprecated="false">
    <value_of entity_check="at least one" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[pat]}</value_of>
</xmlfilecontent_state>\n'''


patch_driver = cveprey.oraclePatches()
patch_driver._init_patch_session("skokkanthi@loginsoft.com", "OS@login123")

class Webcenter():
    r'''
    Oracle WebCenter Portal
    '''
    def __init__(self, cve:str):
        self.cve = cve
        self.criteria = ""
        self.tests = ""
        self.pat_tests = ""
        self.pat_objects = ""
        self.states = ""
        self.pat_states = ""
        cve_info = cveprey.CVE(cve)
        cve_info.get_nvd_data()
        self.desc = cve_info.nvd_data.description
        try:
            self.title = re.findall(r"(\w+\s\w+\s\w+\s\(component\:[^\d]+\))", self.desc)[0]
        except IndexError:
            self.title = ""
        
        try:
            links = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link]
            if len(links) > 1:
                print("[!] Multiple Advisory Links Found")
                for link in links:
                    print(link)
                t = int(input("Give Index Link of adv to use : "))
                links = [links[t-1]]
            else:
                links = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link]

        except IndexError:
            links = [input("Provide Adv Link : ")]
        adv = cveprey.oracleAdvisories(links, cve=cve, comp="Oracle WebCenter Portal")
        print ("Adv : ", adv, "\n", links)

        for link, prod in adv.adv_links.items():
            if "Fusion Middleware" in "".join(prod):
                self.adv_link = link
        if len(adv.versions.keys()) < 1:
            if adv.addressed:
                tmp_cve = adv.addressed_cve
                adv = cveprey.oracleAdvisories(links, cve=tmp_cve)
        print("adv.versions: ", adv.versions)
        print("adv.patch_links: ", adv.patch_links)
        print(adv.patch_links['Fusion Middleware'])
        strings = patch_driver._getPatchstrings(cve, adv.patch_links['Fusion Middleware'])
        if len(strings) == 0:
            patch_string = list()
            content = patch_driver.driver.get(adv.patch_links['Fusion Middleware'][0])
            contents = patch_driver.driver.page_source
            root = cveprey._core.lhtml.fromstring(contents)
            strings = root.xpath(f'//table[@rules="all"]//tr[.//*[contains(.//text(),"WebCenter Portal")]]')
            patch_string.extend([" ".join(" ".join(i.xpath('.//text()')).split('\n')) for i in strings])
            if len(patch_string) == 0:
                strings = root.xpath(f'//table//tr[contains(.//text(),"WebCenter Portal")]')
                patch_string.extend([" ".join(" ".join(i.xpath('.//text()')).split('\n')) for i in strings])
            strings = patch_string


        print("Strings: ", strings)
        patch_numbers = re.findall(r'(?i)WebCenter\s+Portal\s*(Bundle\s+Patch|BP|)\s*([\d\.]+)[\(\)\s]+Patch\s+(\d+)', "".join(strings))
        print("patch_numbers 1: ", patch_numbers)


#This is needed if 2 index value is coming
        '''if len(patch_numbers)<1:
            if not strings:
                print("No matching elements found.")
            else:
                patch_numbers = re.findall(r'(?i)WebCenter\s+Portal\s+([\d\.]+)[\(\)\s]+Patch\s+(\d+)', "".join(strings))
                print("patch_numbers 2:", patch_numbers)'''



#This one needed when CVE need to search in Advisory page--------------------------------------------------
        '''if not 'WebCenter Portal' in strings:
            patch_numbers = re.findall(r'(?i)WebCenter\s+Portal\s+([\d\.]+)[\(\)\s]+Patch\s+(\d+)', "".join(strings))
            print("patch_numbers 2: ", patch_numbers)
            '''
#--------------------------------------------------------------------------------------------------------
        try:
            print("Versions 1: ", adv.versions)
            versions = list(map(lambda x: '.'.join(x.split('.')[:-1]) if len(x.split('.'))>4 else x, adv.versions['Fusion Middleware']))
            self.writeCVE(versions, patch_numbers)
        except Exception:
            adid = re.findall(r"/(cpu[a-zA-Z0-9]+).*html", self.adv_link)[0].lower()
            _cvrf = cveprey.oracleCVRF()
            _adv = _cvrf._CVE(cve=cve, adid=adid)
            self.writeCVE(_cvrf.affected_version['WebCenter Portal'])

    def writeCVE(self, versions:list=None, patches=list):
        patch_dic = {}
        _file_ = 'webcenter-Lin-template.xml'

        tmp = open(_file_, 'r')
        content_read = tmp.read()
        tmp.close()
        tmp = open(f'{self.cve.upper()}-lin-oracle-webcenter-portal.xml', 'w')
        for version in sorted(versions):
            patch_dic[version] = {}
            for patch in patches:
                if version in patch[1]:
                    patch_dic[version] = [patch[2]] if version in patch[1] else []
                    if len(patch_dic[version])<1:
                        patch_dic[version] = [patch[2]] if version in patch[1] else []

        print("patch_numbers test: ", patch_dic)
        self.buildData(patch_dic)
        data = {
            'cve': self.cve,
            'cve_raw': "".join(self.cve.split('-')[1::]),
            'title': self.title,
            'adv_link': self.adv_link[0],
            'adid': re.findall(r"/(cpu.*).html", self.adv_link)[0].upper(),
            'adid_r': re.findall(r"/(cpu.*).html", self.adv_link)[0],
            'desc': self.desc,
            'criteria': self.criteria,
            'versions_tests': self.tests,
            'pat_tests': self.pat_tests,
            'version_states': self.states,
            'pat_objects': self.pat_objects,
            'pat_states': self.pat_states
        }
        content_read = content_read.format(data=data)
        tmp.write(content_read)
        tmp.close()

    def buildData(self, patch_dic):
        for version in patch_dic.keys():
            version=".".join(version.split('.')[:-1]) if len(version.split('.'))>4 else version
            version_raw = "".join([f'{ver:0>2}' for ver in version.split('.')])
            data_1 = {
                'version_raw': version_raw,
                'version': version,
                'version_pat': "\.".join(version.split(".")[:-1]) if len(version.split('.'))>4 else "\.".join(version.split("."))
            }
            self.tests += ver_test.format(data=data_1)
            self.states += ver_state.format(data=data_1)
            self.pat_objects += pat_object.format(data=data_1)
            if len(patch_dic[version])>0:
                data_1 = {
                'version_raw': version_raw,
                'pat': patch_dic[version][0],
                'version': ".".join(version.split(".")[:-1]) if len(version.split('.'))>4 else ".".join(version.split("."))
                }
                self.criteria += ver_pat_criteria.format(data=data_1)
                self.tests += pat_test.format(data=data_1)
                self.states += pat_state.format(data=data_1)

            else:
                data_1 = {
                'version_raw': version_raw,
                'version': ".".join(version.split(".")[:-1]) if len(version.split('.'))>4 else ".".join(version.split("."))
                }
                self.criteria += single_ver.format(data=data_1)
            
            

with open('examples.txt', 'r') as file:
    data = file.read().split()

for cve in data:
    Webcenter(cve)
patch_driver.driver.quit()
