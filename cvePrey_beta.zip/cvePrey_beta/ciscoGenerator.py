import cveprey, sys
from datetime import datetime

COUNT = 0

and_criteria_for_prod_ver='''
<criteria operator="AND" negate="false" comment="For {data[prod]} and Version check">
                <criterion test_ref="oval:org.tanium.cisco.asa.cve:tst:{data[cve_raw]}{data[_count]}" negate="false" comment="Check for {data[prod]} on {data[fam]} versions"/>
              </criteria>
'''

test_asa='''
<line_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#asa" id="oval:org.tanium.cisco.asa.cve:tst:{data[cve_raw]}{data[_count]}" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for {data[prod]} on ASA versions" deprecated="false">
      <object object_ref="oval:org.tanium.cisco.asa.cve:obj:1000"/>
      <state state_ref="oval:org.tanium.cisco.asa.cve:ste:{data[cve_raw]}{data[_count]}"/>
    </line_test>
'''

test_ftd='''
<line_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#asa" id="oval:org.tanium.cisco.asa.cve:tst:{data[cve_raw]}{data[_count]}" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for {data[prod]} on FTD versions" deprecated="false">
      <object object_ref="oval:org.tanium.cisco.asa.cve:obj:2000"/>
      <state state_ref="oval:org.tanium.cisco.asa.cve:ste:{data[cve_raw]}{data[_count]}"/>
    </line_test>
'''

state='''
<line_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#asa" id="oval:org.tanium.cisco.asa.cve:ste:{data[cve_raw]}{data[_count]}" version="1" operator="AND" comment="State for Affected {data[prod]} on {data[fam]} versions" deprecated="false">
      <config_line entity_check="all" check_existence="at_least_one_exists" datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.cisco.asa.cve:var:{data[cve_raw]}{data[_count]}" var_check="at least one"/>
    </line_state>
'''

const_var = '''
<constant_variable id="oval:org.tanium.cisco.asa.cve:var:{data[cve_raw]}{data[_count]}" version="1" datatype="string" comment="Affected {data[prod]} on {data[fam]} versions" deprecated="false">
      {data[values]}
    </constant_variable>'''

class _Cisco(cveprey.ciscoAdvisories):
    def __init__(self, cve: str):
        global COUNT
        self.vars = ''
        self.states = ''
        self.tests = ''
        self.criteria_asa = ''
        self.criteria_ftd = ''
        self.cve_raw = "".join(cve.split('-')[1::])
        nvd = cveprey.CVE(cve)
        nvd.get_nvd_data()
        try:
            self.adv_link = [link  for link in nvd.nvd_data.adv_links if "CiscoSecurityAdvisory" in link][0]
        except IndexError:
            adv = cveprey.ciscoSecurityAdvisories()
            self.adv_link = adv.cveData(cve).adv_link

        adv = super().__init__(cve, self.adv_link)
        cvrf = super().cvrf_contents()
        versions = cvrf.affected_versions
        c = cveprey.ciscoMappingVersions()
        for affected_sftw in cvrf.affected_software:
            try:
                if "XE" in affected_sftw:
                    versions[affected_sftw]['Mapped'] = list(map(lambda x: f"<value>{x}</value>", sorted(c.mapped_iosxe_ios(versions[affected_sftw]['All']))))
                    versions[affected_sftw]['All'] = list(map(self.regex_excape_iosxe, sorted(versions[affected_sftw]['All'])))
                    continue
                if "IOS" in affected_sftw:
                    versions[affected_sftw]['Mapped_ios'] = list(map(lambda x: f"<value>{x}</value>", sorted(c.mapped_ios_iosxe(versions[affected_sftw]['All']))))
                    versions[affected_sftw]['All'] = list(map(lambda x: f"<value>{x}</value>", sorted(versions[affected_sftw]['All'])))
                    continue
            except Exception as err:
                versions[affected_sftw]['All'] = ""
                versions[affected_sftw]['Mapped'] = ""
        for family in cvrf.affected_software:
            try:
                if "XE" in family:
                    if not versions[family]['All'] or (len(versions[family]['All']) == 0):
                        versions[family]['Mapped'] = versions['IOS']['All']
                        versions[family]['All'] = versions['IOS']['Mapped_ios']
                    data = {'cve': cve, 'bugid': "", 'title': super().title, 'adid': super().ad_id[0], 'desc': nvd.nvd_data.description, 'cve_raw': "".join(cve.split('-')[1::]), 'date': datetime.now().strftime("%Y-%m-%dT%H:%M:%S:+05:30"), 'product': "Tanium Comply", 'company': "tanium", 'versions': "\n".join(versions[family]['All']), 'versions_mapped': "\n".join(versions[family]['Mapped'])}
                    tem = open("ios_xe.xml", "r")
                    template = tem.read()
                    tem.close()
                    file = open(f"{cve}-iosxe.xml", "w")
                    template = template.format(data=data)
                    file.write(template)
                    file.close()
                elif "XR" in family:
                    continue
                elif ("ASA" in family) or ("Adaptive Security Appliance" in family):
                    print("True 1")
                    # if ("FTD" in versions.keys()) or ("Firepower Threat Defense" in versions.keys()):
                    print("True 2")

                    fam = "".join([v for v in cvrf.affected_software if ("ASA" in v) or ("Adaptive Security Appliance" in v)])
                    for prod in versions[fam].keys():
                        versions[fam][prod] = "\n".join(self.regex_excape_asa(versions[fam][prod]))
                        data = {
                            'prod': prod,
                            'fam': "ASA",
                            'cve_raw': self.cve_raw,
                            '_count': f'{COUNT:0>2}',
                            'values': versions[fam][prod]
                            }
                        self.criteria_asa += and_criteria_for_prod_ver.format(data=data)
                        self.vars += const_var.format(data=data)
                        self.states += state.format(data=data)
                        self.tests += test_asa.format(data=data)
                        COUNT += 1   
                    fam = "".join([v for v in cvrf.affected_software if ("FTD" in v) or ("Firepower Threat Defense" in v)])                    
                    for prod in versions[fam].keys():
                        versions[fam][prod] = "\n".join(self.regex_excape(versions[fam][prod]))
                        data = {
                            'prod': prod,
                            'fam': "FTD",
                            'cve_raw': self.cve_raw,
                            '_count': f'{COUNT:0>2}',
                            'values': versions[fam][prod]
                            }
                        self.criteria_ftd += and_criteria_for_prod_ver.format(data=data)
                        self.vars += const_var.format(data=data)
                        self.states += state.format(data=data)
                        self.tests += test_ftd.format(data=data)
                        COUNT += 1
                    data = {
                        'title': super().title,
                        'cve': self.cve,
                        'cve_raw': self.cve_raw,
                        'adid': super().ad_id[0],
                        'desc': nvd.nvd_data.description,
                        'tests': self.tests,
                        'states': self.states,
                        'vars': self.vars,
                        'criteria_asa': self.criteria_asa,
                        'criteria_ftd': self.criteria_ftd
                    }
                    tem = open("asa.xml.tmp", "r")
                    template = tem.read()
                    tem.close()
                    file = open(f"{cve}-asa-ftd.xml", "w")
                    template = template.format(data=data)
                    file.write(template)
                    file.close() 
                else:
                    data = {'cve': cve, 'bugid': "", 'title': super().title, 'adid': super().ad_id[0], 'desc': nvd.nvd_data.description, 'cve_raw': "".join(cve.split('-')[1::]), 'date': datetime.now().strftime("%Y-%m-%dT%H:%M:%S:+05:30"), 'product': "Tanium Comply", 'company': "tanium", 'versions_ios': "\n".join(versions[family]['All'])}
                    tem = open(f"ios.xml", "r")
                    template = tem.read()
                    tem.close()
                    file = open(f"{cve}-ios.xml", "w")
                    template = template.format(data=data)
                    file.write(template)
                    file.close()
            except Exception as err:
                print(err, "Dont Know")
                continue
    def regex_excape_iosxe(self, val):
        val = val.replace('.', '\.0*')
        val = f"^0*{val}$"
        pat = cveprey._core.re.findall("[a-zA-Z]", val)
        if pat:
            ver_list=list(dict.fromkeys(pat))
            for mem in ver_list:
                val=cveprey._core.re.sub(mem,"["+mem.upper()+mem.lower()+"]",val)
            ret = val
        else:
            ret = val

        ret = ret.replace("[", "\.?[", 1)
        return "<value>"+ret+"</value>"
    
    def regex_excape_asa(self, values):
        tmp = list()
        for val in values:
            k = (val.replace('.', '(', 2).replace('(', '.', 1)+")").replace('.', '\.').replace('(', '\(').replace(')', '\)')
            tmp.append("<value>"+k+"</value>")
        return tmp
    
    def regex_excape(self, values):
        tmp = list()
        for val in values:
            k = val.replace('.', '\.')
            tmp.append("<value>"+k+"</value>")
        return tmp
    

_Cisco(sys.argv[1])