import lxml.html as lhtml, sys, json
import pandas as pd


ver_patch_criteria = '''
<criteria operator="AND" negate="false" comment="Check for {data[ver]} and its patches (newer versions)">
 <criterion test_ref="oval:org.tanium.windows.oracle.cve:tst:1000" negate="false" comment="Check for Oracle Home"/>
 <criterion test_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:14{data[ver_id]}00" negate="false" comment="Check for Oracle JDeveloper for Windows affected version equals to {data[ver]} (newer versions)"/>
 <criterion test_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:14{data[patch]}04" negate="true" comment="Check for Oracle JDeveloper for Windows affected patch greater than or equal to {data[patch]} (newer versions)"/>
</criteria>
<criteria operator="AND" negate="false" comment="Check for {data[ver]} and its patches (older versions)">
 <criterion test_ref="oval:org.tanium.windows.oracle.cve:tst:1001" negate="false" comment="Check for Oracle beahomelist"/>
 <criterion test_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:1488{data[ver_id]}00" negate="false" comment="Check for Oracle JDeveloper for Windows affected version equals to {data[ver]} (older version baehome path)"/>
 <criterion test_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:1488{data[patch]}04" negate="true" comment="Check for Oracle JDeveloper for Windows affected patch greater than or equal to {data[patch]} (older version baehome path)"/>
</criteria>
'''

ver_criteria = '''
<criteria operator="AND" negate="false" comment="Check for {data[ver]} (newer versions)">
 <criterion test_ref="oval:org.tanium.windows.oracle.cve:tst:1000" negate="false" comment="Check for Oracle Home"/>
 <criterion test_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:14{data[ver_id]}00" negate="false" comment="Check for Oracle JDeveloper for Windows affected version equals to {data[ver]} (newer versions)"/>
</criteria>
<criteria operator="AND" negate="false" comment="Check for {data[ver]} (older versions)">
 <criterion test_ref="oval:org.tanium.windows.oracle.cve:tst:1001" negate="false" comment="Check for Oracle beahomelist"/>
 <criterion test_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:1488{data[ver_id]}00" negate="false" comment="Check for Oracle JDeveloper for Windows affected version equals to {data[ver]} (older version baehome path)"/>
</criteria>
'''

ver_patch_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:14{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle JDeveloper for Windows affected version equals to {data[ver]} (newer versions)" deprecated="false">
 <object object_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:obj:1002"/>
 <state state_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:ste:14{data[ver_id]}00"/>
</xmlfilecontent_test>
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:14{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle JDeveloper for Windows affected patch greater than or equal to {data[patch]} (newer versions)" deprecated="false">
 <object object_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:obj:1400{data[ver_id]}"/>
 <state state_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:ste:14{data[patch]}04"/>
</xmlfilecontent_test>
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:1488{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle JDeveloper for Windows affected version equals to {data[ver]} (older version baehome path)" deprecated="false">
 <object object_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:obj:2004"/>
 <state state_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:ste:14{data[ver_id]}00"/>
</xmlfilecontent_test>
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:1488{data[patch]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle JDeveloper for Windows affected patch greater than or equal to {data[patch]} (older version baehome path)" deprecated="false">
 <object object_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:obj:148800{data[ver_id]}"/>
 <state state_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:ste:14{data[patch]}04"/>
</xmlfilecontent_test>
'''

ver_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:14{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle JDeveloper for Windows affected version equals to {data[ver]} (newer versions)" deprecated="false">
 <object object_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:obj:1002"/>
 <state state_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:ste:14{data[ver_id]}00"/>
</xmlfilecontent_test>
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:tst:1488{data[ver_id]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle JDeveloper for Windows affected version equals to {data[ver]} (older version baehome path)" deprecated="false">
 <object object_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:obj:2004"/>
 <state state_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:ste:14{data[ver_id]}00"/>
</xmlfilecontent_test>
'''

patch_obj = '''
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:obj:1400{data[ver_id]}" version="1" comment="Object that collects installed patch version (newer versions)" deprecated="false">
    <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:var:1003" var_check="at least one"/>
    <xpath datatype="string" operation="equals" mask="false">//*[//components[contains(@internal_name, "oracle.jdeveloper") or @internal_name="oracle.jrf.adfrt" and @version="{data[ver]}"] and name()="patch_id" or name()="reference_id"]/@number</xpath>
    <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.windows.oracle.jdeveloper.cve:ste:1000</filter>
</xmlfilecontent_object>
<xmlfilecontent_object xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:obj:148800{data[ver_id]}" version="1" comment="Object that collects installed patch version (older version baehome path)" deprecated="false">
    <filepath datatype="string" operation="pattern match" mask="false" var_ref="oval:org.tanium.windows.oracle.jdeveloper.cve:var:2002" var_check="at least one"/>
    <xpath datatype="string" operation="equals" mask="false">//*[//components[contains(@internal_name, "oracle.jdeveloper") or @internal_name="oracle.jrf.adfrt" and @version="{data[ver]}"] and name()="patch_id" or name()="reference_id"]/@number</xpath>
    <filter xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5" action="include">oval:org.tanium.windows.oracle.jdeveloper.cve:ste:1000</filter>
</xmlfilecontent_object>
'''

ver_patch_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:ste:14{data[patch]}04" version="1" operator="AND" comment="State for Oracle JDeveloper patch greater than equal to {data[patch]}" deprecated="false">
    <value_of entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[patch]}</value_of>
</xmlfilecontent_state>
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:ste:14{data[ver_id]}00" version="1" operator="AND" comment="State for Oracle JDeveloper is equals {data[ver]}" deprecated="false">
    <value_of entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="equals" mask="false">{data[ver]}</value_of>
</xmlfilecontent_state>
'''

ver_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.windows.oracle.jdeveloper.cve:ste:14{data[ver_id]}00" version="1" operator="AND" comment="State for Oracle JDeveloper is equals {data[ver]}" deprecated="false">
    <value_of entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="equals" mask="false">{data[ver]}</value_of>
</xmlfilecontent_state>
'''

class ChangeTemplateWindows():
    def __init__(self, cve_file: str):
        criteria = ''
        tests = ''
        objects = ''
        states = ''
        fs = open(cve_file, 'r')
        content = fs.read().encode('utf-8')
        fs.close()
        raw = lhtml.fromstring(content)
        cve = raw.xpath('//reference[@source="CVE"]/@ref_id')[0]
        print(f"Generating {cve} ... ")
        version_json_cve = pd.read_csv('/home/sujan/Documents/work/OracleJDeveloperFinal.csv').fillna(1)
        version_json_cve[version_json_cve.columns[1::]] = version_json_cve[version_json_cve.columns[1::]].astype('int')        
        versions = list(set(raw.xpath('//value_of[@operation="equals"]/text()')))
        for ver in versions:
            try:
              patch = version_json_cve[version_json_cve.CVE == f"{cve}"].get(ver).item()
            except Exception as e:
               print(e)
               continue
            data = {
                'ver': ver,
                'ver_id': "".join([f'{_ver:0>2}' for _ver in ver.split('.')]),
                'patch': patch,
            }
            if str(patch) == "0":
              criteria += ver_criteria.format(data=data)
              tests += ver_test.format(data=data)
              states += ver_state.format(data=data)
              continue
            criteria += ver_patch_criteria.format(data=data)
            tests += ver_patch_test.format(data=data)
            states += ver_patch_state.format(data=data)
            objects += patch_obj.format(data=data)
            if str(patch) not in states:
              states += ver_patch_state.format(data=data)

        fs_r = open('/home/sujan/OVAL/src/tmp/win-oracle-jdeveloper.xml', 'r')
        content_r_tmp = fs_r.read()
        fs_r.close()
        data = {
            'criteria': criteria,
            'tests': tests,
            'states': states,
            'objects': objects,
            'states': states,
            'cve': cve,
            'cve_raw': "".join(cve.split('-')[1::]),
            'title': raw.xpath('//definition[@class="vulnerability"]//title/text()')[0],
            'desc': raw.xpath('//definition[@class="vulnerability"]//description/text()')[0],
            'adid': raw.xpath('//definition[@class="vulnerability"]//reference[@source="VENDOR"]/@ref_id')[0],
            'adurl': raw.xpath('//definition[@class="vulnerability"]//reference[@source="VENDOR"]/@ref_url')[0]
        }
        content = content_r_tmp.format(data=data)
        fs_w = open(f"{cve}-win-oracle-jdeveloper.xml", "w")
        fs_w.write(content)
        fs_w.close()
        
ChangeTemplateWindows(sys.argv[1])