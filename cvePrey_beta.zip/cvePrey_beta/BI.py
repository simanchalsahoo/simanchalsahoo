import cveprey, sys, re

single_ver = '''
<criterion test_ref="oval:org.tanium.unix.oracle.ebusiness.suite.cve:tst:11{data[version_raw]}00" negate="false" comment="Check for Oracle E-Business Suite for Linux version equals to {data[version]}"/>\n'''

multiple_log = '''
<criteria operator="AND" negate="false" comment="multiple versions">
    <criteria operator="OR" negate="false" comment="multiple versions">
        {data[mul_versions]}
    </criteria>
    <criterion test_ref="oval:org.tanium.unix.oracle.ebusiness.suite.cve:tst:14{data[pat]}04" negate="true" comment="Check for Oracle E-Business Suite for Linux Patches greater than or equal to {data[pat]}"/>
</criteria>
'''

ver_pat_crit = '''
<criteria operator="AND" negate="false" comment="version for {data[version]}">
    <criterion test_ref="oval:org.tanium.unix.oracle.ebusiness.suite.cve:tst:11{data[version_raw]}00" negate="false" comment="Check for Oracle E-Business Suite for Linux version equals to {data[version]}"/>
    <criterion test_ref="oval:org.tanium.unix.oracle.ebusiness.suite.cve:tst:14{data[pat]}04" negate="true" comment="Check for Oracle E-Business Suite for Linux version {data[version]} Patches greater than or equal to {data[pat]}"/>
</criteria>\n'''

ver_test = '''
<textfilecontent54_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.ebusiness.suite.cve:tst:11{data[version_raw]}00" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle E-Business Suite for Linux version equals to {data[version]}" deprecated="false">
    <object object_ref="oval:org.tanium.unix.oracle.ebusiness.suite.cve:obj:1003"/>
    <state state_ref="oval:org.tanium.unix.oracle.ebusiness.suite.cve:ste:11{data[version_raw]}00"/>
</textfilecontent54_test>\n'''
pat_test = '''
<xmlfilecontent_test xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.ebusiness.suite.cve:tst:14{data[pat]}04" version="1" check_existence="at_least_one_exists" check="at least one" state_operator="AND" comment="Check for Oracle E-Business Suite for Linux version {data[version]} Patches greater than or equal to {data[pat]}" deprecated="false">
    <object object_ref="oval:org.tanium.unix.oracle.ebusiness.suite.cve:obj:10031"/>
    <state state_ref="oval:org.tanium.unix.oracle.ebusiness.suite.cve:ste:14{data[pat]}04"/>
</xmlfilecontent_test>\n'''

ver_state = '''
<textfilecontent54_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.ebusiness.suite.cve:ste:11{data[version_raw]}00" version="1" operator="AND" comment="State for Oracle E-Business Suite is equals to {data[version]}" deprecated="false">
    <subexpression entity_check="all" check_existence="at_least_one_exists" datatype="version" operation="equals" mask="false">{data[version]}</subexpression>
</textfilecontent54_state>\n'''

pat_state = '''
<xmlfilecontent_state xmlns="http://oval.mitre.org/XMLSchema/oval-definitions-5#independent" id="oval:org.tanium.unix.oracle.ebusiness.suite.cve:ste:14{data[pat]}04" version="1" operator="AND" comment="State for Oracle E-Business Suite is greater than or equal to {data[pat]} patches" deprecated="false">
    <value_of entity_check="at least one" check_existence="at_least_one_exists" datatype="version" operation="greater than or equal" mask="false">{data[pat]}</value_of>
</xmlfilecontent_state>\n'''

class BI():
    r'''
    Oracle E-Business Suite
    '''
    def __init__(self, cve:str):
        self.cve = cve
        self.criteria = ""
        self.tests = ""
        self.pat_tests = ""
        self.states = ""
        self.pat_states = ""
        cve_info = cveprey.CVE(cve)
        cve_info.get_nvd_data()
        self.desc = cve_info.nvd_data.description
        # self.title = re.findall(r"([Vv]ulnerability.*\s+component)", self.desc)[0]
        self.title = ""
        try:
            links = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link]
            if len(links) > 1:
                print("[!] Multiple Advisory Links Found")
                for link in links:
                    print(link)
                t = int(input("Give Index Link of adv to use : "))
                self.adv_link = links[t-1]
            else:
                self.adv_link = [link for link in cve_info.nvd_data.adv_links if "/cpu" in link][0]
        except IndexError:
            self.adv_link = input("Provide Adv Link : ")
        adv = cveprey.oracleAdvisories(self.adv_link, cve=cve)
        print(adv.versions.keys())
        try:
            self.writeCVE(adv.versions['Oracle Fusion Middeware Risk Matrix'])
        except Exception:
            adid = re.findall(r"/(cpu[a-zA-Z0-9]+).*html", self.adv_link)[0].lower()
            _cvrf = cveprey.oracleCVRF()
            _adv = _cvrf._CVE(cve=cve, adid=adid, new=1)
            print(_cvrf.affected_family)
            # self.writeCVE(_cvrf.affected_version['Oracle E-Business Suite'])

    def writeCVE(self, versions:list=None):
        patch_dic = {}
        if "Oracle Applications Framework" in self.desc:
            _file_ = 'lin-EBS-template-oaf.xml'
        elif "Applications Desktop Integrator" in self.desc:
            _file_ = 'lin-EBS-template-bne-di.xml'
        else:
            _file_ = 'lin-EBS-template-no-comp.xml'

        tmp = open(_file_, 'r')
        content_read = tmp.read()
        tmp.close()
        tmp = open(f'{self.cve.upper()}-lin-ebs.xml', 'w')
        for version in versions:
            if '-' in version:
                rangie = list(map(lambda x: int(x.strip().split('.')[-1]), version.split('-')))
                for ver in range(rangie[0], rangie[1]+1):
                    ver = ".".join(list(map(lambda x: x.strip().split('.')[0:2], version.split('-')))[0])+f'.{ver}'
                    pat = input(f"Please Give Patch for {ver} : ")
                    try:
                        if not patch_dic[pat]:
                            patch_dic[pat] = list()
                    except Exception:
                        patch_dic[pat] = list()
                    patch_dic[pat].append(ver)
            else:
                pat = input(f"Please Give Patch for {version} : ")
                try:
                    if not patch_dic[pat]:
                        patch_dic[pat] = list()
                except Exception:
                    patch_dic[pat] = list()
                patch_dic[pat].append(version.strip())
        self.buildData(patch_dic)
        data = {
            'cve': self.cve,
            'cve_raw': "".join(self.cve.split('-')[1::]),
            'title': self.title,
            'adv_link': self.adv_link ,
            'adid': re.findall(r"/(cpu.*).html", self.adv_link)[0].upper(),
            'adid_r': re.findall(r"/(cpu.*).html", self.adv_link)[0],
            'desc': self.desc,
            'versions_criterion': self.criteria,
            'versions_tests': self.tests,
            'pat_tests': self.pat_tests,
            'version_states': self.states,
            'pat_states': self.pat_states
        }
        content_read = content_read.format(data=data)
        tmp.write(content_read)
        tmp.close()

    def buildData(self, patch_dic):
        for patch_id in patch_dic.keys():
            if len(patch_dic[patch_id]) > 1:
                t = ""
                for version in patch_dic[patch_id]:
                    version_raw = "".join([f'{ver:0>2}' for ver in version.split('.')])
                    data_1 = {
                        'version_raw': version_raw,
                        'pat': patch_id,
                        'version': version
                    }
                    t += single_ver.format(data=data_1)
                    if f"11{version_raw}00" not in self.tests:
                        self.tests += ver_test.format(data=data_1)
                        self.states += ver_state.format(data=data_1)
                    if f"14{patch_id}04" not in self.pat_tests:
                        self.pat_tests += pat_test.format(data=data_1)
                        self.pat_states += pat_state.format(data=data_1)
                data_2 = {
                    'mul_versions': t,
                    'pat': patch_id
                }
                self.criteria += multiple_log.format(data=data_2)
                data = {data_2.update(data_1)}
            else:
                version = patch_dic[patch_id][0]
                version_raw = "".join([f'{ver:0>2}' for ver in version.split('.')])
                data = {
                    'version': version,
                    'pat': patch_id,
                    'version_raw': version_raw
                }
                self.criteria += ver_pat_crit.format(data=data)

                if f"11{version_raw}00" not in self.tests:
                    self.tests += ver_test.format(data=data)
                    self.states += ver_state.format(data=data)
                if f"14{patch_id}04" not in self.pat_tests:
                    self.pat_tests += pat_test.format(data=data)
                    self.pat_states += pat_state.format(data=data)

BI(sys.argv[1])